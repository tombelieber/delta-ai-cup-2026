const STORE_KEY = "zhixin.watch.v1";
const LIVE_PREFIX = "zhixin.live.";
const validVideoId = (value) => typeof value === "string" && /^[A-Za-z0-9_-]{11}$/.test(value);
const emptyData = () => ({ schemaVersion: 1, recordingEnabled: true, recordingEpoch: 0, goal: "", videos: {} });
function mergeIntervals(ranges, duration = Infinity) {
  const sorted = (Array.isArray(ranges) ? ranges : []).filter((range) => Array.isArray(range) && range.length === 2 && range.every(Number.isFinite)).map(([start, end]) => [Math.max(0, start), Math.min(duration, end)]).filter(([start, end]) => end > start).sort((a, b) => a[0] - b[0]);
  return sorted.reduce((result, range) => {
    const last = result.at(-1);
    if (last && range[0] <= last[1]) last[1] = Math.max(last[1], range[1]);
    else result.push([...range]);
    return result;
  }, []);
}
function normalizeData(value) {
  if (!value || value.schemaVersion !== 1) return emptyData();
  const data = {
    ...emptyData(),
    recordingEnabled: value.recordingEnabled !== false,
    recordingEpoch: Number.isSafeInteger(value.recordingEpoch) && value.recordingEpoch >= 0 ? value.recordingEpoch : 0,
    goal: typeof value.goal === "string" ? value.goal.slice(0, 200) : ""
  };
  for (const [id, video] of Object.entries(value.videos || {})) {
    if (!validVideoId(id) || !video || !(Number.isFinite(video.duration) && video.duration > 0)) continue;
    data.videos[id] = {
      videoId: id,
      title: typeof video.title === "string" ? video.title.slice(0, 300) : "YouTube 影片",
      duration: video.duration,
      ranges: mergeIntervals(video.ranges, video.duration),
      updatedAt: Number.isFinite(video.updatedAt) ? video.updatedAt : 0
    };
  }
  return data;
}
function applyRecording(data, { videoId, title, duration, ranges }, now = Date.now()) {
  if (!data.recordingEnabled || !validVideoId(videoId) || !Number.isFinite(duration) || duration <= 0) return data;
  const added = mergeIntervals(ranges, duration);
  if (!added.length) return data;
  const previous = data.videos[videoId];
  const merged = mergeIntervals([...previous?.ranges || [], ...added], duration);
  const safeTitle = typeof title === "string" && title.trim() ? title.slice(0, 300) : previous?.title || "YouTube 影片";
  if (previous && previous.duration === duration && previous.title === safeTitle && JSON.stringify(previous.ranges) === JSON.stringify(merged)) return data;
  return { ...data, videos: { ...data.videos, [videoId]: { videoId, title: safeTitle, duration, ranges: merged, updatedAt: now } } };
}
const isYouTubeUrl = (value) => {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === "www.youtube.com";
  } catch {
    return false;
  }
};
function youtubeVideoId(value) {
  try {
    const url = new URL(value);
    const id = url.searchParams.get("v");
    return isYouTubeUrl(value) && url.pathname === "/watch" && validVideoId(id) ? id : null;
  } catch {
    return null;
  }
}
function createRepository(storage, now = Date.now) {
  let queue = Promise.resolve();
  const run = (operation) => {
    const result = queue.then(operation);
    queue = result.catch(() => {
    });
    return result;
  };
  const read = async () => normalizeData((await storage.get(STORE_KEY))[STORE_KEY]);
  return {
    read: () => run(read),
    update: (operation) => run(async () => {
      const before = await read();
      const after = operation(before, now());
      if (after !== before) await storage.set({ [STORE_KEY]: after });
      return after;
    })
  };
}
const episodes = [
  {
    id: "cursor",
    series: "Lenny’s Podcast",
    guest: "Michael Truell · Cursor",
    title: "The rise of Cursor",
    subtitle: "The $300M ARR AI tool that engineers can’t stop using",
    fullTitle: "The rise of Cursor: The $300M ARR AI tool that engineers can’t stop using | Michael Truell",
    topic: "產品體驗，點樣變成競爭優勢？",
    date: "2025.05.01",
    videoId: "En5cSXgGvZM",
    official: "https://www.lennysnewsletter.com/p/the-rise-of-cursor-michael-truell",
    start: "38:45",
    end: "46:16",
    excerpt: "7 分 31 秒",
    color: "peach",
    cover: "CURSOR",
    coverSub: "BUILDING AN AI PRODUCT",
    overview: "以 AI 開發工具為背景，探索產品體驗、工作流程同持續創新，點樣構成一個產品嘅競爭優勢。",
    points: [
      { title: "由一個功能，走入日常工作流程", body: "假設產品能連接用戶每日嘅工作，價值就唔只係單次輸出；比較時要留意，便利係來自整合，定只係多咗功能。", explanation: "示例：將「生成一段程式碼」同「協助完成整個修改流程」分開睇。後者可能減少切換工具，但仍要用實際使用情境驗證。" },
      { title: "好體驗，要靠細節持續累積", body: "假設競爭對手都用到相近模型，速度、穩定性同操作細節，就可能影響用戶會唔會持續使用。", explanation: "示例：同樣做到一項任務，較少等待、較易修正嘅流程可能更有吸引力。呢個係討論用假設，未有節目逐字稿或用戶測試支持。" },
      { title: "優勢需要隨模型能力更新", body: "假設底層模型不斷進步，今日有用嘅功能未必長期稀缺；產品需要重新確認，自己解決緊邊個問題。", explanation: "示例：模型更新後，原本要多步先完成嘅工作可能變得簡單。團隊可重新測試自己嘅流程，睇價值有冇改變。" }
    ]
  },
  {
    id: "yc",
    series: "YC · Lightcone",
    guest: "Y Combinator",
    title: "The 7 Most Powerful Moats For AI Startups",
    subtitle: "AI 新創嘅競爭優勢",
    fullTitle: "The 7 Most Powerful Moats For AI Startups",
    topic: "AI 產品可以靠乜留住用戶？",
    date: "2025.10.03",
    videoId: "bxBzsSsqQAM",
    official: "https://www.ycombinator.com/library/Mx-the-7-most-powerful-moats-for-ai-startups",
    start: "19:30",
    end: "31:24",
    excerpt: "11 分 54 秒",
    color: "orange",
    cover: "LIGHTCONE",
    coverSub: "THE STARTUP PERSPECTIVE",
    overview: "以 AI 新創為背景，探索轉換成本、產品定位同競爭者嘅限制，作為思考競爭優勢嘅起點。",
    points: [
      { title: "轉換成本，可能來自累積嘅工作", body: "假設用戶已將資料同工作流程放入產品，轉用另一工具嘅成本可能增加；但成本高唔等於體驗好。", explanation: "示例：搬走多年整理嘅資料需要時間。討論競爭優勢時，可以分開考慮資料遷移成本同用戶滿意度。" },
      { title: "定位取捨，會限制競爭者跟進", body: "假設一個新做法會影響既有業務，競爭者即使有技術能力，都未必願意立即採用。", explanation: "示例：一個更簡單嘅產品模式，可能同大型公司原有嘅收費或服務方式有衝突。實際情況仍要逐間公司核實。" },
      { title: "講優勢之前，先講清楚條件", body: "假設一項優勢只喺特定客群或規模先出現，就需要將條件一齊保留，避免將框架直接當成答案。", explanation: "示例：有大量用戶先出現嘅網絡效應，未必能幫到第一批用戶。討論時應講清楚適用階段。" }
    ]
  },
  {
    id: "anthropic",
    series: "Lenny’s Podcast",
    guest: "Mike Krieger · Anthropic",
    title: "Anthropic’s CPO on what comes next",
    subtitle: "AI 創辦人可以揀邊啲機會？",
    fullTitle: "Anthropic’s CPO on what comes next | Mike Krieger",
    topic: "模型進步之後，產品機會喺邊？",
    date: "2025.06.05",
    videoId: "DKrBGOFs0GY",
    official: "https://www.lennysnewsletter.com/p/anthropics-cpo-heres-what-comes-next",
    start: "47:16",
    end: "52:03",
    excerpt: "4 分 47 秒",
    color: "lavender",
    cover: "WHAT’S NEXT",
    coverSub: "THE MODEL COMPANY VIEW",
    overview: "從模型公司嘅角度，探索領域知識、接近客戶同互動方式，點樣幫創辦人選擇產品機會。",
    points: [
      { title: "領域知識，可以幫你揀對問題", body: "假設團隊熟悉一個行業嘅工作細節，就可能更早發現值得解決嘅問題；仍要向用戶確認需求。", explanation: "示例：熟悉一個工作流程，可以幫團隊提出更具體嘅問題，但熟悉行業唔等於已驗證付費意願。" },
      { title: "接近客戶，先知道工具漏咗乜", body: "假設團隊能持續觀察客戶點工作，就可以用回饋修正流程，而唔只係增加新功能。", explanation: "示例：請用戶示範一次真實任務，可能比直接問佢想要乜功能更容易見到困難。呢度係 UI 討論用例子。" },
      { title: "新能力，值得配一個新互動方式", body: "假設模型做到以前做唔到嘅工作，沿用舊介面未必最方便；可以先測試一個更直接嘅操作。", explanation: "示例：由填多個表格，改成先選一個任務再逐步補充資料。是否更好，仍要靠實際操作測試。" }
    ]
  }
];
function seconds(value) {
  if (!/^\d{1,3}:[0-5]\d(?::[0-5]\d)?$/.test(value.trim())) return null;
  return value.trim().split(":").reduce((total, part) => total * 60 + Number(part), 0);
}
const formatTime = (value) => {
  const total = Math.max(0, Math.floor(value));
  const minutes = Math.floor(total / 60);
  return `${minutes}:${String(total % 60).padStart(2, "0")}`;
};
function mergeRanges(ranges) {
  const sorted = ranges.filter(([start, end]) => Number.isFinite(start) && Number.isFinite(end) && end > start && start >= 0).map((range) => [...range]).sort((a, b) => a[0] - b[0]);
  return sorted.reduce((result, range) => {
    const previous = result.at(-1);
    if (previous && range[0] <= previous[1]) previous[1] = Math.max(previous[1], range[1]);
    else result.push(range);
    return result;
  }, []);
}
const watchedSeconds = (ranges) => mergeRanges(ranges).reduce((sum, [start, end]) => sum + end - start, 0);
const learningRoute = [
  { episodeId: "cursor", title: "Cursor：產品工作流程" },
  { episodeId: "yc", title: "YC：AI 新創護城河" },
  { episodeId: "anthropic", title: "Anthropic：產品機會" }
].map((step) => {
  const episode = episodes.find((item) => item.id === step.episodeId);
  const start = seconds(episode.start), end = seconds(episode.end);
  return { ...step, start, end, duration: end - start };
});
function getLearningRouteProgress(memory = []) {
  const steps = learningRoute.map((step) => {
    const ranges = memory.filter((item) => item.episodeId === step.episodeId).flatMap((item) => item.ranges || []).filter(([start, end]) => Number.isFinite(start) && Number.isFinite(end) && end > start).map(([start, end]) => [Math.max(step.start, start), Math.min(step.end, end)]);
    const coveredRanges = mergeRanges(ranges);
    const gaps = [];
    let position = step.start;
    for (const [start, end] of coveredRanges) {
      if (start > position) gaps.push([position, start]);
      position = Math.max(position, end);
    }
    if (position < step.end) gaps.push([position, step.end]);
    const watched2 = watchedSeconds(coveredRanges), remaining = step.duration - watched2;
    return {
      ...step,
      coveredRanges,
      gaps,
      watchedSeconds: watched2,
      remainingSeconds: remaining,
      status: remaining === 0 ? "done" : watched2 > 0 ? "partial" : "todo",
      isNext: false
    };
  });
  const nextStep = steps.find((step) => step.gaps.length);
  if (nextStep) nextStep.isNext = true;
  const totalSeconds = steps.reduce((sum, step) => sum + step.duration, 0);
  const watched = steps.reduce((sum, step) => sum + step.watchedSeconds, 0);
  const complete = !nextStep;
  return {
    steps,
    totalSeconds,
    watchedSeconds: watched,
    remainingSeconds: totalSeconds - watched,
    completedSteps: steps.filter((step) => step.status === "done").length,
    totalSteps: steps.length,
    percent: complete ? 100 : Math.min(99, Math.floor(watched / totalSeconds * 100)),
    complete,
    next: nextStep ? { episodeId: nextStep.episodeId, title: nextStep.title, time: nextStep.gaps[0][0] } : null
  };
}
const ANALYSIS_SETTINGS_KEY = "zhixin.analysis.settings.v1";
const ANALYSIS_RESULT_KEY = "zhixin.analysis.result.v1";
const DEFAULT_API_ENDPOINT = "https://delta-assistant-613646062582.us-central1.run.app";
const ANALYSIS_SOURCE_METHODS = Object.freeze(["gemini_youtube_video", "local_gemma_transcript"]);
const ANALYSIS_CHAPTERS = [
  { videoId: "En5cSXgGvZM", start: 2325, end: 2776 },
  { videoId: "bxBzsSsqQAM", start: 1170, end: 1884 },
  { videoId: "DKrBGOFs0GY", start: 2836, end: 3123 }
];
function normalizeApiEndpoint(value) {
  if (typeof value !== "string" || value.length > 2048) throw Error("Enter the API service URL.");
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw Error("Enter a valid API service URL.");
  }
  const local = ["127.0.0.1", "localhost"].includes(url.hostname);
  if (!(url.protocol === "https:" || local && url.protocol === "http:") || url.username || url.password || url.search || url.hash || url.pathname !== "/") {
    throw Error("Use an HTTPS domain, or localhost HTTP for local development. Omit paths, credentials, and parameters.");
  }
  return url.origin;
}
const endpointPermission = (endpoint) => {
  const url = new URL(normalizeApiEndpoint(endpoint));
  return `${url.protocol}//${url.hostname}/*`;
};
function analysisPayload(data) {
  const stored = normalizeData(data);
  const watched = ANALYSIS_CHAPTERS.map(({ videoId, start, end }) => ({
    videoId,
    ranges: mergeIntervals((stored.videos[videoId]?.ranges || []).map(([from, to]) => [Math.max(start, from), Math.min(end, to)]))
  })).filter((item) => item.ranges.length);
  const goal = stored.goal.trim();
  return { schemaVersion: 1, ...goal ? { goal } : {}, watched };
}
const analysisFingerprint = (data) => JSON.stringify(analysisPayload(data));
const text$3 = (value, max = 4e3) => {
  if (typeof value !== "string" || !value.trim() || value.length > max) throw Error("Invalid analysis service response format.");
  return value;
};
const covered = (source2, payload) => (payload.watched.find((item) => item.videoId === source2.videoId)?.ranges || []).some(([start, end]) => start <= source2.start && end >= source2.end);
const overlaps = (source2, payload) => (payload.watched.find((item) => item.videoId === source2.videoId)?.ranges || []).some(([start, end]) => start < source2.end && end > source2.start);
function source(value) {
  const chapter = ANALYSIS_CHAPTERS.find((item) => item.videoId === value?.videoId);
  if (!chapter || !Number.isFinite(value.start) || !Number.isFinite(value.end) || value.start < chapter.start || value.end > chapter.end || value.end <= value.start) {
    throw Error("Analysis source is outside the supported chapters.");
  }
  return {
    unitId: text$3(value.unitId, 200),
    videoId: chapter.videoId,
    start: value.start,
    end: value.end,
    url: `https://www.youtube.com/watch?v=${chapter.videoId}&t=${Math.floor(value.start)}s`
  };
}
function validateAnalysisResponse(value, payload) {
  if (!value || value.schemaVersion !== 1 || !["ready", "no_history", "insufficient_source", "unavailable"].includes(value.status) || !Array.isArray(value.memory) || value.memory.length > 100 || !Array.isArray(value.limitations) || value.limitations.length > 30 || !Number.isFinite(Date.parse(value.generatedAt)) || !value.source || !ANALYSIS_SOURCE_METHODS.includes(value.source.method) || value.source.verification !== "ai_derived_not_human_verified" || !Array.isArray(value.source.chapters) || value.source.chapters.length > 3) {
    throw Error("Invalid analysis service response format.");
  }
  const memory = value.memory.map((item) => {
    const citation = source(item.source);
    if (!covered(citation, payload)) throw Error("Analysis memory cites an unplayed range.");
    if (!Array.isArray(item.conditions) || item.conditions.length > 20) throw Error("Invalid analysis service response format.");
    return { id: text$3(item.id, 200), summary: text$3(item.summary), conditions: item.conditions.map((item2) => text$3(item2)), source: citation };
  });
  if (new Set(memory.map((item) => item.id)).size !== memory.length) throw Error("Duplicate analysis memory IDs.");
  if (value.status === "no_history" && memory.length) throw Error("A watched baseline is required to claim personal added value.");
  let recommendation = null;
  if (value.recommendation !== null) {
    const item = value.recommendation;
    if (!item || !["repeated", "new_example", "new_idea", "opposing", "unknown"].includes(item.relation) || !["relevant", "limited", "unknown"].includes(item.usefulness) || !Array.isArray(item.comparedTo) || item.comparedTo.length > 100) throw Error("Invalid analysis service response format.");
    const candidateSource = source(item.candidateSource);
    if (overlaps(candidateSource, payload)) throw Error("The recommended clip includes a played range. Run the analysis again.");
    const comparedTo = item.comparedTo.map((comparison) => {
      const baseline = memory.find((entry) => entry.id === comparison.memoryId);
      const citation = source(comparison.source);
      if (!baseline || JSON.stringify(baseline.source) !== JSON.stringify(citation)) throw Error("The comparison baseline has no matching watched memory.");
      return { memoryId: baseline.id, source: citation };
    });
    if (value.status === "no_history" && (memory.length || comparedTo.length || item.relation !== "unknown")) throw Error("A watched baseline is required to claim personal added value.");
    if (item.relation !== "unknown" && !comparedTo.length) throw Error("The added-value classification is missing a watched source.");
    recommendation = {
      id: text$3(item.id, 200),
      title: text$3(item.title, 500),
      summary: text$3(item.summary),
      relation: item.relation,
      adds: text$3(item.adds),
      reason: text$3(item.reason),
      usefulness: item.usefulness,
      candidateSource,
      comparedTo
    };
  }
  if (value.status === "ready" && (!memory.length || !recommendation)) throw Error("The personal comparison is missing a watched source.");
  if (value.status === "unavailable" && recommendation) throw Error("An incomplete comparison cannot return a recommendation.");
  return {
    schemaVersion: 1,
    status: value.status,
    reason: value.reason === null ? null : text$3(value.reason, 100),
    generatedAt: value.generatedAt,
    source: {
      method: value.source.method,
      model: value.source.model === null ? null : text$3(value.source.model, 200),
      indexVersion: text$3(value.source.indexVersion, 200),
      verification: value.source.verification,
      chapters: value.source.chapters.map((chapter) => {
        const allowed = ANALYSIS_CHAPTERS.find((item) => item.videoId === chapter.videoId);
        if (!allowed || chapter.start !== allowed.start || chapter.end !== allowed.end || !["ready", "unavailable"].includes(chapter.status)) throw Error("Invalid analysis chapter source.");
        return { ...allowed, status: chapter.status };
      })
    },
    memory,
    recommendation,
    limitations: value.limitations.map((item) => text$3(item))
  };
}
async function fetchAnalysis(endpoint, payload, { fetcher = globalThis.fetch, timeoutMs = 3e5, signal } = {}) {
  const origin2 = normalizeApiEndpoint(endpoint);
  const body = JSON.stringify(payload);
  if (payload.watched.some((item) => item.ranges.length > 160) || new TextEncoder().encode(body).length > 16384) {
    throw Error("Watch segments exceed the MVP limit of 160 ranges per video or 16 KB per analysis. Your local watch history is saved.");
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (signal?.aborted) controller.abort();
  signal?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetcher(`${origin2}/api/recommendations`, {
      method: "POST",
      credentials: "omit",
      redirect: "error",
      referrerPolicy: "no-referrer",
      headers: { "Content-Type": "application/json" },
      body,
      signal: controller.signal
    });
    if (!response.ok) throw Error(response.status === 429 ? "The analysis service is busy. Try again later." : "The analysis service could not complete the request. Your watch history is saved.");
    const raw = await response.text();
    if (raw.length > 3e5) throw Error("The analysis response is too large. Try again.");
    return validateAnalysisResponse(JSON.parse(raw), payload);
  } catch (error) {
    if (signal?.aborted) throw Error("Analysis stopped. Your watch history is saved.");
    if (error.name === "AbortError") throw Error("Analysis timed out. Try again later. Your watch history is saved.");
    throw error;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", abort);
  }
}
function savedAnalysisView(saved, data, endpoint) {
  if (!saved || saved.schemaVersion !== 1 || saved.endpoint !== endpoint || typeof saved.fingerprint !== "string" || !saved.result) return null;
  try {
    const payload = JSON.parse(saved.fingerprint);
    const result = validateAnalysisResponse(saved.result, payload);
    return { ...result, stale: saved.fingerprint !== analysisFingerprint(data) };
  } catch {
    return null;
  }
}
const MAP_CLASSIFICATION_KEY = "delta.map.classifications.v1";
const MAP_CONTENT_TYPES = Object.freeze(["knowledge", "entertainment", "unknown"]);
const MAP_CONFIDENCE_LEVELS = Object.freeze(["high", "medium", "low"]);
const MAX_DATE$2 = 864e13;
const object$5 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const text$2 = (value, max) => typeof value === "string" ? value.normalize("NFC").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max) : "";
const time = (value) => typeof value === "number" && Number.isFinite(value) && value > 0 && value <= MAX_DATE$2 ? value : null;
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const canonical = (value) => value.toLocaleLowerCase("en").replace(/\s+/g, " ").trim();
const empty$1 = () => ({ schemaVersion: 1, assignments: {}, reviews: {}, updatedAt: null });
function validMapLabel(value) {
  return typeof value === "string" && value === value.trim() && value.length > 0 && value.length <= 80 && /[A-Za-z]/u.test(value) && /^[\p{Script=Latin}\p{M}\p{N} &'’+.,()\-/:!?_%–—]+$/u.test(value) && !/https?:|www\.|[\u0000-\u001f\u007f]/i.test(value);
}
function normalizeMapPath(value) {
  if (!Array.isArray(value) || value.length < 2 || value.length > 4 || !value.every(validMapLabel)) return null;
  const path = value.map((label) => label.normalize("NFC").replace(/\s+/g, " "));
  if (new Set(path.map(canonical)).size !== path.length || canonical(path[0]) === "more to explore") return null;
  return path;
}
function origin(value) {
  if (typeof value !== "string" || value.length > 2048) return null;
  try {
    const url = new URL(value.trim());
    if (!(url.protocol === "https:" || url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) return null;
    return url.origin;
  } catch {
    return null;
  }
}
function metadata(entry) {
  if (!object$5(entry) || !validVideoId(entry.videoId)) return null;
  const title = text$2(entry.title, 400);
  if (!title) return null;
  const channel = text$2(entry.channel ?? entry.channelTitle ?? entry.creator, 160);
  return { videoId: entry.videoId, title, ...channel ? { channel } : {} };
}
function mapMetadataFingerprint(entry) {
  const value = metadata(entry);
  return value ? `map-v1:${JSON.stringify({ title: value.title, ...value.channel ? { channel: value.channel } : {} })}` : null;
}
function validFingerprint(value) {
  if (typeof value !== "string" || !value.startsWith("map-v1:") || value.length > 1200) return false;
  try {
    const parsed = JSON.parse(value.slice(7));
    return mapMetadataFingerprint({ videoId: "abcdefghijk", ...parsed }) === value;
  } catch {
    return false;
  }
}
function mapAssignmentMatches(assignment, record) {
  if (!object$5(assignment) || !object$5(record) || assignment.videoId !== record.videoId || !validVideoId(record.videoId) || !validFingerprint(assignment.metadataFingerprint)) return false;
  const current = metadata(record);
  if (!current) return false;
  const submitted = JSON.parse(assignment.metadataFingerprint.slice(7));
  return submitted.title === current.title && !(submitted.channel && current.channel && submitted.channel !== current.channel);
}
function mapReviewMatches(review, record) {
  const normalized = object$5(record) ? normalizeReview(review, record.videoId) : null;
  return Boolean(normalized && mapAssignmentMatches(normalized, record));
}
function metadataForMap(entries) {
  return dedupeRecords(entries).map(metadata).filter(Boolean);
}
function normalizeAssignment(value, videoId) {
  if (!object$5(value) || !validVideoId(videoId) || value.videoId != null && value.videoId !== videoId) return null;
  const path = normalizeMapPath(value.path);
  const endpoint = origin(value.endpoint);
  if (!path || !validFingerprint(value.metadataFingerprint) || !MAP_CONFIDENCE_LEVELS.includes(value.confidence) || !MAP_CONTENT_TYPES.includes(value.contentType) || !endpoint || !text$2(value.model, 160) || time(value.classifiedAt) === null) return null;
  return {
    videoId,
    path,
    confidence: value.confidence,
    contentType: value.contentType,
    metadataFingerprint: value.metadataFingerprint,
    classifiedAt: value.classifiedAt,
    endpoint,
    model: text$2(value.model, 160),
    source: "ai"
  };
}
function normalizeReview(value, videoId) {
  if (!object$5(value) || !validVideoId(videoId) || value.videoId != null && value.videoId !== videoId) return null;
  const endpoint = origin(value.endpoint);
  if (!validFingerprint(value.metadataFingerprint) || !endpoint || !text$2(value.model, 160) || time(value.reviewedAt) === null) return null;
  return {
    videoId,
    metadataFingerprint: value.metadataFingerprint,
    reviewedAt: value.reviewedAt,
    endpoint,
    model: text$2(value.model, 160)
  };
}
function latestUpdate(store) {
  let latest = store.updatedAt || 0;
  for (const assignment of Object.values(store.assignments)) latest = Math.max(latest, assignment.classifiedAt);
  for (const review of Object.values(store.reviews)) latest = Math.max(latest, review.reviewedAt);
  return latest || null;
}
function normalizeMapClassifications(value) {
  if (!object$5(value) || value.schemaVersion !== 1 || !object$5(value.assignments)) return empty$1();
  const result = empty$1();
  for (const [videoId, raw] of Object.entries(value.assignments)) {
    const assignment = normalizeAssignment(raw, videoId);
    if (assignment) result.assignments[videoId] = assignment;
  }
  for (const [videoId, raw] of Object.entries(object$5(value.reviews) ? value.reviews : {})) {
    const review = normalizeReview(raw, videoId);
    if (review) result.reviews[videoId] = review;
  }
  result.updatedAt = time(value.updatedAt);
  return result;
}
function markMapReviewed(current, records, { now = Date.now(), endpoint, model } = {}) {
  const result = normalizeMapClassifications(current);
  for (const record of metadataForMap(records)) {
    const review = normalizeReview({
      videoId: record.videoId,
      metadataFingerprint: mapMetadataFingerprint(record),
      reviewedAt: now,
      endpoint,
      model
    }, record.videoId);
    if (!review) continue;
    const previous = result.reviews[record.videoId];
    if (!previous || review.reviewedAt >= previous.reviewedAt) result.reviews[record.videoId] = review;
  }
  result.updatedAt = latestUpdate(result);
  return result;
}
function calendarDay(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day2] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day2);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day2 ? time(date.getTime()) : null;
}
function mapEntryTime(entry) {
  if (!object$5(entry)) return null;
  const observed = [
    time(entry.lastActivityAt),
    time(entry.visitedAt),
    calendarDay(entry.date),
    ...Array.isArray(entry.historyDates) ? entry.historyDates.map((item) => calendarDay(item?.date)) : []
  ].filter((value) => value !== null);
  return observed.length ? observed.reduce((latest, value) => Math.max(latest, value), 0) : null;
}
function mergeRecords(a, b) {
  const newer = (mapEntryTime(b) || 0) >= (mapEntryTime(a) || 0) ? b : a;
  const older = newer === b ? a : b;
  const result = { ...older, ...newer, title: text$2(newer.title, 500) || text$2(older.title, 500) || "YouTube video" };
  for (const key of ["hasPlayback", "imported", "accountHistory", "learningStarted", "hasLesson"]) {
    if (a[key] === true || b[key] === true) result[key] = true;
  }
  for (const key of ["watchedSeconds", "checkedTasks"]) {
    const values = [a[key], b[key]].filter((value) => Number.isFinite(value) && value >= 0);
    if (values.length) result[key] = Math.max(...values);
  }
  const tasks = [...Array.isArray(a.tasks) ? a.tasks : [], ...Array.isArray(b.tasks) ? b.tasks : []];
  if (tasks.length) {
    const byTask = /* @__PURE__ */ new Map();
    for (const task of tasks) {
      if (!object$5(task) || typeof task.taskId !== "string") continue;
      const previous = byTask.get(task.taskId);
      if (!previous || (Date.parse(task.checkedAt) || 0) >= (Date.parse(previous.checkedAt) || 0)) byTask.set(task.taskId, { ...task });
    }
    result.tasks = [...byTask.values()];
  }
  const dates = [...Array.isArray(a.historyDates) ? a.historyDates : [], ...Array.isArray(b.historyDates) ? b.historyDates : []];
  if (dates.length) result.historyDates = [...new Map(dates.filter(object$5).map((item) => [JSON.stringify(item), { ...item }])).values()];
  return result;
}
function dedupeRecords(entries) {
  const byVideo = /* @__PURE__ */ new Map();
  for (const entry of Array.isArray(entries) ? entries : []) {
    if (!object$5(entry) || !validVideoId(entry.videoId)) continue;
    const previous = byVideo.get(entry.videoId);
    byVideo.set(entry.videoId, previous ? mergeRecords(previous, entry) : { ...entry });
  }
  return [...byVideo.values()].sort((a, b) => (mapEntryTime(b) || 0) - (mapEntryTime(a) || 0) || compare(a.videoId, b.videoId));
}
function mapTimeBounds(range = "all", now = Date.now()) {
  if (!["week", "month"].includes(range)) return null;
  const end = time(now);
  if (end === null) return { start: null, end: null };
  const date = new Date(end);
  date.setHours(0, 0, 0, 0);
  if (range === "week") date.setDate(date.getDate() - (date.getDay() + 6) % 7);
  else date.setDate(1);
  return { start: date.getTime(), end };
}
const mapPathId = (path) => `topic:${path.map((label) => encodeURIComponent(canonical(label))).join("/")}`;
function makeNode(label, path, unresolved = false) {
  return {
    id: mapPathId(path),
    label,
    path: [...path],
    count: 0,
    lastActive: null,
    recentCount: 0,
    children: [],
    records: [],
    directRecords: [],
    unresolved,
    _children: /* @__PURE__ */ new Map()
  };
}
function buildPersonalMap(entries, { classifications, range = "all", sort = "balanced", now = Date.now() } = {}) {
  const all = dedupeRecords(entries);
  const bounds = mapTimeBounds(range, now), week = mapTimeBounds("week", now);
  const records = all.filter((entry) => {
    if (!bounds) return true;
    const at = mapEntryTime(entry);
    return at !== null && bounds.start !== null && at >= bounds.start && at <= bounds.end;
  });
  const assignments = normalizeMapClassifications(classifications).assignments;
  const root = {
    ...makeNode("My map", []),
    id: "root",
    total: all.length,
    classified: 0,
    unresolved: 0,
    stale: 0,
    range: ["week", "month", "all"].includes(range) ? range : "all",
    sort: ["volume", "recent", "balanced"].includes(sort) ? sort : "balanced"
  };
  for (const record of records) {
    const assignment = assignments[record.videoId];
    const fresh = mapAssignmentMatches(assignment, record);
    const creator = metadata(record)?.channel;
    const path = fresh ? assignment.path : ["More to explore", creator && validMapLabel(creator) ? creator : "Needs context"];
    const viewRecord = { ...record, topicLabel: fresh ? assignment.path.at(-1) : "Not yet grouped" };
    if (fresh) root.classified++;
    else {
      root.unresolved++;
      if (assignment) root.stale++;
    }
    const at = mapEntryTime(record);
    const recent = at !== null && week?.start !== null && at >= week.start && at <= week.end;
    let node = root;
    for (let depth = 0; depth <= path.length; depth++) {
      node.records.push(viewRecord);
      node.count++;
      if (at !== null) node.lastActive = Math.max(node.lastActive || 0, at);
      if (recent) node.recentCount++;
      if (depth === path.length) {
        node.directRecords.push(viewRecord);
        break;
      }
      const key = canonical(path[depth]);
      if (!node._children.has(key)) {
        const child = makeNode(path[depth], path.slice(0, depth + 1), !fresh);
        node._children.set(key, child);
        node.children.push(child);
      }
      node = node._children.get(key);
    }
  }
  const recency = (node) => node.lastActive && time(now) !== null ? Math.exp(-Math.max(0, now - node.lastActive) / (7 * 864e5)) : 0;
  const score = (node) => Math.log1p(node.count) + 1.5 * Math.log1p(node.recentCount) + recency(node);
  const compareNodes = (a, b) => Number(a.unresolved) - Number(b.unresolved) || (root.sort === "volume" ? b.count - a.count || (b.lastActive || 0) - (a.lastActive || 0) : root.sort === "recent" ? (b.lastActive || 0) - (a.lastActive || 0) || b.count - a.count : score(b) - score(a) || b.count - a.count || (b.lastActive || 0) - (a.lastActive || 0)) || compare(canonical(a.label), canonical(b.label));
  const nodes = [];
  function finish(node) {
    node.children.sort(compareNodes);
    delete node._children;
    nodes.push(node);
    for (const child of node.children) finish(child);
  }
  finish(root);
  root.nodes = nodes.slice(1);
  return root;
}
const scriptRel = "modulepreload";
const assetsURL = function(dep, importerUrl) {
  return new URL(dep, importerUrl).href;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    let allSettled = function(promises$2) {
      return Promise.all(promises$2.map((p) => Promise.resolve(p).then((value$1) => ({
        status: "fulfilled",
        value: value$1
      }), (reason) => ({
        status: "rejected",
        reason
      }))));
    };
    const links = document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector("meta[property=csp-nonce]");
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = allSettled(deps.map((dep) => {
      dep = assetsURL(dep, importerUrl);
      if (dep in seen) return;
      seen[dep] = true;
      const isCss = dep.endsWith(".css");
      const cssSelector = isCss ? '[rel="stylesheet"]' : "";
      if (!!importerUrl) for (let i$1 = links.length - 1; i$1 >= 0; i$1--) {
        const link$1 = links[i$1];
        if (link$1.href === dep && (!isCss || link$1.rel === "stylesheet")) return;
      }
      else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) return;
      const link = document.createElement("link");
      link.rel = isCss ? "stylesheet" : scriptRel;
      if (!isCss) link.as = "script";
      link.crossOrigin = "";
      link.href = dep;
      if (cspNonce) link.setAttribute("nonce", cspNonce);
      document.head.appendChild(link);
      if (isCss) return new Promise((res, rej) => {
        link.addEventListener("load", res);
        link.addEventListener("error", () => rej(/* @__PURE__ */ new Error(`Unable to preload CSS for ${dep}`)));
      });
    }));
  }
  function handlePreloadError(err$2) {
    const e$1 = new Event("vite:preloadError", { cancelable: true });
    e$1.payload = err$2;
    window.dispatchEvent(e$1);
    if (!e$1.defaultPrevented) throw err$2;
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const MAP_HOSTED_ENDPOINT = DEFAULT_API_ENDPOINT;
const MAP_HOSTED_BATCH_SIZE = 10;
const usesHostedMap = (endpoint) => endpoint === MAP_HOSTED_ENDPOINT;
class MapAnalysisError extends Error {
  constructor(message, { code = "SERVICE_UNAVAILABLE", status = null, paused = true, retryAfterMs = null } = {}) {
    super(message);
    this.name = "MapAnalysisError";
    this.code = code;
    this.status = status;
    this.paused = paused;
    this.retryAfterMs = retryAfterMs;
  }
}
function normalizeMapEndpoint(value) {
  if (typeof value !== "string" || value.length > 2048) throw new MapAnalysisError("Enter the map service URL.", { code: "INVALID_ENDPOINT" });
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw new MapAnalysisError("Enter a valid map service URL.", { code: "INVALID_ENDPOINT" });
  }
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (!(url.protocol === "https:" || local && url.protocol === "http:") || url.username || url.password || url.search || url.hash || url.pathname !== "/") {
    throw new MapAnalysisError("Use an HTTPS origin, or localhost HTTP for development.", { code: "INVALID_ENDPOINT" });
  }
  return url.origin;
}
function invalidResponse() {
  return new MapAnalysisError("The map service returned an invalid result. Your records are saved.", { code: "INVALID_RESPONSE" });
}
function validateMapAnalysisResponse(value, videos) {
  const submitted = new Map(videos.map((video) => [video.videoId, video]));
  if (!value || value.schemaVersion !== 1 || !Array.isArray(value.items) || value.items.length > submitted.size || typeof value.model !== "string" || !value.model.trim() || value.model.length > 160 || !Number.isSafeInteger(value.cached) || value.cached < 0 || value.cached > submitted.size) throw invalidResponse();
  const seen2 = /* @__PURE__ */ new Set();
  const items = value.items.map((item) => {
    const path = normalizeMapPath(item?.path);
    if (!item || !submitted.has(item.videoId) || seen2.has(item.videoId) || !path || !MAP_CONFIDENCE_LEVELS.includes(item.confidence) || !MAP_CONTENT_TYPES.includes(item.contentType)) throw invalidResponse();
    seen2.add(item.videoId);
    return {
      videoId: item.videoId,
      path,
      confidence: item.confidence,
      contentType: item.contentType,
      metadataFingerprint: mapMetadataFingerprint(submitted.get(item.videoId))
    };
  });
  let unresolved;
  const unresolvedValues = value.unresolvedIds ?? value.unresolved;
  if (unresolvedValues != null) {
    if (!Array.isArray(unresolvedValues) || unresolvedValues.length > submitted.size) throw invalidResponse();
    unresolved = unresolvedValues.map((item) => {
      const videoId = typeof item === "string" ? item : item?.videoId;
      if (!submitted.has(videoId) || seen2.has(videoId)) throw invalidResponse();
      seen2.add(videoId);
      return { videoId, reason: typeof item?.reason === "string" ? item.reason.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 200) : "Insufficient context" };
    });
  }
  unresolved ||= [];
  for (const videoId of submitted.keys()) if (!seen2.has(videoId)) unresolved.push({ videoId, reason: "No classification returned" });
  return {
    schemaVersion: 1,
    items,
    cached: value.cached,
    model: value.model.trim(),
    unresolved,
    unresolvedIds: unresolved.map((item) => item.videoId)
  };
}
function retryAfter(value) {
  if (typeof value !== "string") return null;
  const seconds2 = Number(value);
  if (Number.isFinite(seconds2) && seconds2 >= 0) return Math.min(864e5, seconds2 * 1e3);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.min(864e5, Math.max(0, date - Date.now())) : null;
}
function createMapAnalysisClient({
  fetchImpl = globalThis.fetch,
  timeoutMs = 12e4,
  openHostedAction: openHostedAction2 = (options) => __vitePreload(() => Promise.resolve().then(() => hostedActionClient), true ? void 0 : void 0, import.meta.url).then((module) => module.openHostedAction(options))
} = {}) {
  if (typeof fetchImpl !== "function") throw new TypeError("A fetch implementation is required.");
  let verifiedHosted = false;
  async function verifyHostedAccess(endpoint, { signal } = {}) {
    const origin2 = normalizeMapEndpoint(endpoint);
    if (!usesHostedMap(origin2)) return "private";
    if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
    const controller = new AbortController(), abort = () => controller.abort();
    signal?.addEventListener("abort", abort, { once: true });
    const timer = setTimeout(abort, Math.min(Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : 12e4, 15e3));
    verifiedHosted = false;
    try {
      const response = await fetchImpl(`${origin2}/api/study/auth-config`, { method: "GET", credentials: "omit", redirect: "error", referrerPolicy: "no-referrer", signal: controller.signal });
      if (!response.ok) throw new Error("Unavailable");
      const raw = await response.text();
      if (controller.signal.aborted || signal?.aborted) throw new Error("Aborted");
      if (raw.length > 16e3 || JSON.parse(raw)?.enabled !== true) throw new Error("Invalid configuration");
      verifiedHosted = true;
      return "google";
    } catch {
      if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
      throw new MapAnalysisError("Google sign-in is unavailable. Map analysis is paused; saved records are kept.", { code: "AUTH_UNAVAILABLE" });
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
    }
  }
  return {
    verifyHostedAccess,
    async classify(endpoint, { videos, existingPaths = [], signal: payloadSignal } = {}, { accessToken, signal: requestSignal } = {}) {
      const signal = requestSignal ?? payloadSignal;
      const origin2 = normalizeMapEndpoint(endpoint);
      const metadata2 = metadataForMap(videos);
      if (!metadata2.length) return { schemaVersion: 1, items: [], cached: 0, model: "none", unresolved: [], unresolvedIds: [] };
      const hosted = usesHostedMap(origin2);
      if (!hosted && accessToken != null && (typeof accessToken !== "string" || !/^[A-Za-z0-9_-]{20,256}$/.test(accessToken))) {
        throw new MapAnalysisError("The private map access token is invalid.", { code: "INVALID_ACCESS_TOKEN" });
      }
      if (metadata2.length > 300) throw new MapAnalysisError("Analyze at most 300 videos per batch. Your records are saved.", { code: "INVALID_REQUEST" });
      if (hosted && metadata2.length > MAP_HOSTED_BATCH_SIZE) throw new MapAnalysisError("Analyze at most 10 videos per signed-in batch. Your records are saved.", { code: "INVALID_REQUEST" });
      if (!Array.isArray(existingPaths) || existingPaths.length > 80) throw new MapAnalysisError("Existing map paths are invalid.", { code: "INVALID_REQUEST" });
      const paths = [...new Map(existingPaths.map((path) => {
        if (!Array.isArray(path) || path.length < 1 || path.length > 4 || !path.every(validMapLabel)) throw new MapAnalysisError("Existing map paths are invalid.", { code: "INVALID_REQUEST" });
        const normalized = path.map((label) => label.normalize("NFC").replace(/\s+/g, " "));
        return [JSON.stringify(normalized), normalized];
      })).values()];
      if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
      if (hosted) {
        if (!verifiedHosted) await verifyHostedAccess(origin2, { signal });
        try {
          const value = await openHostedAction2({ action: "classify", endpoint: origin2, payload: { videos: metadata2, existingPaths: paths }, signal });
          if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
          const result = validateMapAnalysisResponse(value, metadata2);
          const uncertain = result.items.filter((item) => item.confidence !== "high").map((item) => ({ videoId: item.videoId, reason: "More context is needed" }));
          return {
            ...result,
            items: result.items.filter((item) => item.confidence === "high"),
            unresolved: [...result.unresolved, ...uncertain],
            unresolvedIds: [...result.unresolvedIds, ...uncertain.map((item) => item.videoId)]
          };
        } catch (issue2) {
          if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
          if (issue2 instanceof MapAnalysisError) throw issue2;
          const code = typeof issue2?.code === "string" && /^[a-zA-Z0-9_]{1,80}$/.test(issue2.code) ? issue2.code : "HOSTED_UNAVAILABLE";
          const status = Number.isSafeInteger(issue2?.status) && issue2.status >= 400 && issue2.status <= 599 ? issue2.status : null;
          throw new MapAnalysisError(code === "free_tier_quota_exhausted" ? "Gemini provider quota has been reached. Map analysis is paused; your saved records are kept." : code === "project_budget_exhausted" ? "Delta’s shared project AI budget is used or reserved. Your saved records are kept." : status === 402 ? "This selection exceeds your remaining history allowance. Choose fewer videos. Check Starter Pack availability in the Learning lab; your saved records are kept." : status === 429 ? "Your free AI allowance is unavailable or used up. Map analysis is paused; saved records are kept." : code === "CANCELLED" ? "Map analysis stopped. Your records are saved." : "Map analysis could not finish in the Delta website. Your records and previous results are saved.", { code, status });
        }
      }
      const controller = new AbortController();
      const abort = () => controller.abort();
      signal?.addEventListener("abort", abort, { once: true });
      const duration = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : 12e4;
      const timer = setTimeout(abort, duration);
      try {
        const response = await fetchImpl(`${origin2}/api/map/classify`, {
          method: "POST",
          credentials: "omit",
          redirect: "error",
          referrerPolicy: "no-referrer",
          headers: { "Content-Type": "application/json", ...accessToken ? { "x-delta-map-token": accessToken } : {} },
          body: JSON.stringify({ videos: metadata2, existingPaths: paths }),
          signal: controller.signal
        });
        if (!response.ok) {
          const status = response.status;
          let body = null;
          try {
            const raw2 = await response.text();
            if (raw2.length < 16e3) body = JSON.parse(raw2);
          } catch {
          }
          const source2 = body?.error && typeof body.error === "object" ? body.error : body;
          const candidateCode = typeof body?.error === "string" ? body.error : source2?.code;
          const code = typeof candidateCode === "string" && /^[a-zA-Z0-9_]{1,80}$/.test(candidateCode) ? candidateCode : status === 402 ? "This selection exceeds your remaining history allowance. Choose fewer videos. Check Starter Pack availability in the Learning lab; your saved records are kept." : status === 429 ? "QUOTA" : status === 403 ? "FORBIDDEN" : "SERVICE_UNAVAILABLE";
          const retry = Number.isFinite(source2?.retryAfterSeconds) && source2.retryAfterSeconds >= 0 ? Math.min(864e5, source2.retryAfterSeconds * 1e3) : retryAfter(response.headers?.get?.("retry-after"));
          throw new MapAnalysisError(
            code === "classification_busy" ? "Map analysis is busy and has paused. Your records are saved." : status === 402 ? "This selection exceeds your remaining history allowance. Choose fewer videos. Check Starter Pack availability in the Learning lab; your saved records are kept." : status === 429 ? "Free model quota reached. Map analysis is paused; your records are saved." : status === 403 ? "Map analysis is not allowed. Your records are saved." : "Map analysis is unavailable. Your records are saved.",
            { code, status, retryAfterMs: retry }
          );
        }
        const raw = await response.text();
        if (controller.signal.aborted) throw Object.assign(new Error("Aborted"), { name: "AbortError" });
        if (raw.length > 2e6) throw invalidResponse();
        let value;
        try {
          value = JSON.parse(raw);
        } catch {
          throw invalidResponse();
        }
        return validateMapAnalysisResponse(value, metadata2);
      } catch (error) {
        if (signal?.aborted) throw new MapAnalysisError("Map analysis stopped. Your records are saved.", { code: "CANCELLED" });
        if (error?.name === "AbortError" || controller.signal.aborted) throw new MapAnalysisError("Map analysis timed out. Your records are saved.", { code: "TIMEOUT" });
        if (error instanceof MapAnalysisError) throw error;
        throw new MapAnalysisError("Map analysis could not connect. Your records are saved.", { code: "NETWORK" });
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
      }
    }
  };
}
const object$4 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const integer = (value) => Number.isSafeInteger(value) && value >= 0;
const invalid = () => {
  throw Error("The import allowance response could not be verified. Your saved records are kept.");
};
function importPayload(value) {
  if (!object$4(value) || typeof value.operationId !== "string" || !/^[-A-Za-z0-9_]{1,128}$/.test(value.operationId) || !Array.isArray(value.videoIds) || value.videoIds.length < 1 || value.videoIds.length > 100 || !value.videoIds.every((id) => typeof id === "string" && /^[-A-Za-z0-9_]{11}$/.test(id))) invalid();
  return { operationId: value.operationId, videoIds: [...new Set(value.videoIds)] };
}
function importBalance(value) {
  if (!object$4(value) || (!Number.isSafeInteger(value.limit) || value.limit < 10 || value.limit > 3210) || !integer(value.used) || value.used > value.limit || value.remaining !== value.limit - value.used) invalid();
  return { limit: value.limit, used: value.used, remaining: value.remaining };
}
function importReceipt(value, expected) {
  const result = importPayload(value), input = importPayload(expected), imports = importBalance(value.imports);
  if (result.operationId !== input.operationId || result.videoIds.length !== input.videoIds.length || !input.videoIds.every((id) => result.videoIds.includes(id)) || !integer(value.added) || value.added > input.videoIds.length || value.added > imports.used) invalid();
  return { ...result, added: value.added, imports };
}
const LEARNING_PILOT = Object.freeze({
  videoId: "dI8w0utjUc0",
  kind: "knowledge",
  start: 35,
  end: 186,
  url: "https://www.youtube.com/watch?v=dI8w0utjUc0&t=35s"
});
function learningSourceVideo(video = {}) {
  const source2 = video || {};
  return source2.videoId === LEARNING_PILOT.videoId ? { ...source2, start: LEARNING_PILOT.start, end: LEARNING_PILOT.end } : { ...source2 };
}
const LEARNING_SOURCE_REGISTRY_VERSION = "sumif-caption-anchors-2026-10-17-v1";
const anchors = Object.freeze([
  Object.freeze({
    id: "sumif-purpose",
    start: 36,
    end: 76,
    statement: "SUMIF adds sales for one matching region, illustrated by selecting North as a single condition."
  }),
  Object.freeze({
    id: "sumif-arguments",
    start: 88,
    end: 125,
    statement: "The walkthrough selects the region range, enters North as the criterion, then selects the sales values to sum."
  }),
  Object.freeze({
    id: "sumif-result-check",
    start: 125,
    end: 146,
    statement: "The North total is checked against the matching sales values to confirm the conditional sum."
  }),
  Object.freeze({
    id: "sumif-cell-reference",
    start: 146,
    end: 186,
    statement: "A cell reference can replace the typed criterion and produce the same total; directly entered text needs quotation marks."
  })
]);
const REVIEWED_SUMIF_SOURCE = Object.freeze({
  videoId: "dI8w0utjUc0",
  videoTitle: "How to use SUMIF and SUMIFS in Microsoft Excel",
  videoUrl: "https://www.youtube.com/watch?v=dI8w0utjUc0",
  start: 35,
  end: 186,
  anchors
});
function reviewedLearningSource(requested) {
  if (requested.videoId !== REVIEWED_SUMIF_SOURCE.videoId) return null;
  const start = Math.max(requested.start, REVIEWED_SUMIF_SOURCE.start);
  const end = Math.min(requested.end, REVIEWED_SUMIF_SOURCE.end);
  const eligible = anchors.filter((anchor) => anchor.start >= start && anchor.end <= end);
  if (end <= start || eligible.length < 2) return null;
  return {
    source: {
      ...requested,
      title: REVIEWED_SUMIF_SOURCE.videoTitle,
      start,
      end,
      ...start !== requested.start || end !== requested.end ? { requestedClip: { start: requested.start, end: requested.end } } : {}
    },
    anchors: eligible,
    verification: {
      status: "reviewed_source_anchors_ai_lesson_unverified",
      registryVersion: LEARNING_SOURCE_REGISTRY_VERSION,
      method: "server-mapped-caption-anchor-ids",
      reviewedExcerpt: { start: REVIEWED_SUMIF_SOURCE.start, end: REVIEWED_SUMIF_SOURCE.end },
      limitation: "Fixed source anchors were checked against exported English captions for this one excerpt. AI explanations and personalized examples are not verbatim or fully human-verified."
    }
  };
}
const SKILLS_STORE_KEY = "delta-skill-tree-v1";
const SKILLS = Object.freeze([
  Object.freeze({ id: "excel-column-total", label: "Total a column of numbers", method: "SUM" }),
  Object.freeze({ id: "sumif-text-equality", label: "Total revenue for one region", method: "SUMIF" })
]);
const REGION_SKILL = "sumif-text-equality";
const object$3 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const knownSkill = (id) => SKILLS.some((skill) => skill.id === id);
const text$1 = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\u0000-\u001f]/.test(value);
const timestamp$2 = (value) => typeof value === "string" && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value ? value : null;
function serviceOrigin(value) {
  try {
    const url = new URL(value);
    return !url.username && !url.password && !url.search && !url.hash && url.pathname === "/" && (url.protocol === "https:" || url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname)) ? url.origin : null;
  } catch {
    return null;
  }
}
function reviewedSource(value) {
  if (!object$3(value)) return null;
  try {
    const url = new URL(value.videoUrl || value.url || (value.videoId === REVIEWED_SUMIF_SOURCE.videoId ? REVIEWED_SUMIF_SOURCE.videoUrl : ""));
    if (url.protocol !== "https:" || url.username || url.password || url.port || url.hash) return null;
    const videoId = ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) && url.pathname === "/watch" ? url.searchParams.get("v") : url.hostname === "youtu.be" ? url.pathname.slice(1) : null;
    const start = Number(value.start), end = Number(value.end);
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start || end - start > 300 || end > 86400) return null;
    const reviewed = reviewedLearningSource({ videoId, videoUrl: REVIEWED_SUMIF_SOURCE.videoUrl, start, end });
    return reviewed ? { videoUrl: REVIEWED_SUMIF_SOURCE.videoUrl, start: reviewed.source.start, end: reviewed.source.end } : null;
  } catch {
    return null;
  }
}
function normalizedEvidence(value) {
  if (!object$3(value) || value.skillId !== REGION_SKILL || value.registryVersion !== LEARNING_SOURCE_REGISTRY_VERSION || !text$1(value.lessonId, 100) || !text$1(value.taskId, 100) || !text$1(value.formula, 1e3) || !/^=\s*SUMIF\s*\(/i.test(value.formula.trim()) || !Number.isFinite(value.actualTotal)) return null;
  const source2 = reviewedSource(value.source), origin2 = serviceOrigin(value.origin);
  const checkedAt = value.checkedAt == null ? null : timestamp$2(value.checkedAt);
  if (!source2 || !origin2 || value.checkedAt != null && !checkedAt) return null;
  return {
    skillId: REGION_SKILL,
    lessonId: value.lessonId,
    taskId: value.taskId,
    formula: value.formula,
    source: source2,
    registryVersion: LEARNING_SOURCE_REGISTRY_VERSION,
    origin: origin2,
    checkedAt,
    actualTotal: value.actualTotal
  };
}
const evidenceIdentity = (value) => JSON.stringify([value.skillId, value.lessonId, value.taskId, value.formula, value.origin]);
function evidenceList(values) {
  const unique = /* @__PURE__ */ new Map();
  for (const value of Array.isArray(values) ? values.slice(-100) : []) {
    const evidence = normalizedEvidence(value);
    if (evidence) {
      const key = evidenceIdentity(evidence);
      unique.delete(key);
      unique.set(key, evidence);
    }
  }
  return [...unique.values()].slice(-20);
}
function emptySkills() {
  return { schemaVersion: 1, familiarity: {}, activity: {}, evidence: [] };
}
function normalizeSkills(value) {
  const result = emptySkills();
  if (!object$3(value) || value.schemaVersion !== 1) return result;
  for (const { id } of SKILLS) {
    const confirmedAt = timestamp$2(value.familiarity?.[id]?.confirmedAt);
    if (confirmedAt) result.familiarity[id] = { confirmedAt };
    const startedAt = timestamp$2(value.activity?.[id]?.startedAt), source2 = reviewedSource(value.activity?.[id]?.source);
    if (id === REGION_SKILL && startedAt && source2) result.activity[id] = { startedAt, source: source2 };
  }
  result.evidence = evidenceList(value.evidence);
  return result;
}
function setFamiliarity(value, id, familiar, at = (/* @__PURE__ */ new Date()).toISOString()) {
  const result = normalizeSkills(value);
  if (!knownSkill(id) || typeof familiar !== "boolean") return result;
  if (!familiar) delete result.familiarity[id];
  else if (timestamp$2(at)) result.familiarity[id] = { confirmedAt: at };
  return result;
}
function markStarted(value, source2, at = (/* @__PURE__ */ new Date()).toISOString()) {
  const result = normalizeSkills(value), reviewed = reviewedSource(source2);
  if (reviewed && timestamp$2(at) && !result.activity[REGION_SKILL]) result.activity[REGION_SKILL] = { startedAt: at, source: reviewed };
  return result;
}
function createPracticeEvidence({ lesson, task, formula, feedback, origin: origin2, checkedAt } = {}) {
  if (!object$3(lesson) || lesson.skill !== REGION_SKILL || task?.skill !== REGION_SKILL || !text$1(lesson.id, 100) || !text$1(task.id, 100) || feedback?.passed !== true || feedback.code !== "correct" || feedback.method !== "deterministic-formula-validation" || feedback.lessonId !== lesson.id || feedback.taskId !== task.id || feedback.answer !== formula || lesson.sourceVerification?.status !== "reviewed_source_anchors_ai_lesson_unverified" || lesson.sourceVerification.registryVersion !== LEARNING_SOURCE_REGISTRY_VERSION) return null;
  const tasks = [lesson.task, ...Array.isArray(lesson.practiceTasks) ? lesson.practiceTasks : []];
  if (!tasks.some((candidate) => candidate?.id === task.id && candidate.skill === REGION_SKILL)) return null;
  return normalizedEvidence({
    skillId: REGION_SKILL,
    lessonId: lesson.id,
    taskId: task.id,
    formula,
    source: lesson.source,
    registryVersion: LEARNING_SOURCE_REGISTRY_VERSION,
    origin: origin2,
    checkedAt,
    actualTotal: feedback.actualTotal
  });
}
function addPracticeEvidence(value, evidence) {
  const result = normalizeSkills(value), accepted = normalizedEvidence(evidence);
  if (accepted) result.evidence = evidenceList([...result.evidence, accepted]);
  return result;
}
function videoValue(value, source2, origin2) {
  const reviewed = reviewedSource(source2);
  if (!reviewed) return { kind: "unsupported", evidence: [] };
  const record = normalizeSkills(value), endpoint = serviceOrigin(origin2);
  const evidence = record.evidence.filter((item) => item.origin === endpoint && item.source.start < reviewed.end && item.source.end > reviewed.start);
  return { kind: evidence.length ? "review" : record.familiarity[REGION_SKILL] ? "consolidation" : "new", evidence };
}
const MAX_ROWS_PER_SOURCE = 2e3;
const MAX_DATE$1 = 864e13;
const object$2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const cleanText = (value, max) => typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max) : "";
const timestamp$1 = (value) => typeof value === "number" && Number.isFinite(value) && value > 0 && value <= MAX_DATE$1 ? value : null;
const canonicalUrl$1 = (videoId) => `https://www.youtube.com/watch?v=${videoId}`;
const TOPICS = Object.freeze([
  { id: "spreadsheets", label: "Spreadsheets", match: /\b(?:excel|spreadsheets?|google sheets|sumifs?|vlookup|xlookup)\b|試算表|電子表格/i },
  { id: "travel", label: "Travel", match: /\b(?:travel|trips?|tourism|vacation|itinerary|packing|airports?|tokyo|taipei|japan|hong kong|jr\s*pass|rail\s*pass)\b|旅行|旅遊|九州|由布院|新幹線/i },
  { id: "fitness", label: "Fitness", match: /\b(?:fitness|workouts?|exercises?|strength training|yoga|pilates|gym|running|marathon)\b|健身|運動教學/i },
  { id: "cats", label: "Cats", match: /\b(?:cats?|kittens?|feline)\b|貓/i },
  { id: "gaming", label: "Gaming", match: /\b(?:gameplay|gaming|games?|minecraft|roblox|pokemon|fortnite|gamers?)\b|遊戲|電玩/i },
  { id: "music", label: "Music", match: /\b(?:music|songs?|concerts?|guitar|piano|singing|singers?|albums?|soundtrack|orchestra|live session|fancam)\b|音樂|歌曲|演唱會/i },
  { id: "sports", label: "Sports", match: /\b(?:sports?|football|soccer|basketball|tennis|baseball|nba|nfl|hockey|fifa)\b|足球|籃球|體育|劍擊|游泳|亞運/i },
  { id: "finance", label: "Finance", match: /\b(?:finance|financial|invest|investing|investments?|budgeting|budgets?|money)\b|理財|投資|預算/i },
  { id: "coffee", label: "Coffee", match: /\b(?:coffee|espresso|cafe|barista)\b|café|咖啡/i },
  // Specific content topics above take precedence over an incidental AI tag.
  { id: "technology", label: "Technology", match: /\b(?:ai|artificial intelligence|programming|coding|python|javascript|typescript|software|chatgpt|gemini|computers?|technology|tech)\b|人工智能|人工智慧|編程/i }
]);
const ENTERTAINMENT = /\b(?:funny|funniest|memes?|pranks?|vlogs?|gameplay|reactions?|reacts|highlights|trailers?|comedy|stand[- ]?up|full movie|official (?:music )?video|cute (?:cats?|kittens?)|live streams?|livestreams?|game match|fancam|cats? dancing|(?:music|piano|guitar|singing) performance|live session)\b|搞笑|精華|惡搞|演唱會|實況|比賽|貓(?:咪)?.{0,4}(?:跳舞|可愛)/i;
const TEACHING = /\b(?:how to|how does|how do|tutorials?|lessons?|explained|explainers?|step[- ]by[- ]step|learn|guides?|tips|techniques?|workouts?|exercises?)\b|教學|教你|入門|解說/i;
function topicForVideo({ videoId, title } = {}) {
  const text2 = cleanText(title, 300);
  const topic = videoId === LEARNING_PILOT.videoId ? TOPICS[0] : TOPICS.find((item) => item.match.test(text2)) || { id: "other", label: "Other topics" };
  const kind = videoId === LEARNING_PILOT.videoId ? "knowledge" : ENTERTAINMENT.test(text2) ? "entertainment" : TEACHING.test(text2) ? "knowledge" : "unknown";
  return { id: `${topic.id}:${kind}`, label: topic.label, kind };
}
function checkedTasks(values) {
  const byId = /* @__PURE__ */ new Map();
  for (const value of (Array.isArray(values) ? values : []).slice(0, MAX_ROWS_PER_SOURCE)) {
    if (!object$2(value) || typeof value.taskId !== "string" || !value.taskId.trim() || value.taskId.length > 100 || /[\u0000-\u001f\u007f]/.test(value.taskId) || !Number.isFinite(value.total)) continue;
    let checkedAt = null;
    if (value.checkedAt != null) {
      if (typeof value.checkedAt !== "string") continue;
      const parsed = Date.parse(value.checkedAt);
      if (!timestamp$1(parsed) || new Date(parsed).toISOString() !== value.checkedAt) continue;
      checkedAt = value.checkedAt;
    }
    const task = { taskId: value.taskId.trim(), total: value.total, checkedAt, formula: cleanText(value.formula, 1e3) };
    const previous = byId.get(task.taskId);
    if (!previous || (Date.parse(task.checkedAt) || 0) >= (Date.parse(previous.checkedAt) || 0)) byId.set(task.taskId, task);
  }
  return [...byId.values()].sort((a, b) => (Date.parse(b.checkedAt) || 0) - (Date.parse(a.checkedAt) || 0) || a.taskId.localeCompare(b.taskId));
}
function historyDay(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day2] = value.split("-").map(Number), date = new Date(year, month - 1, day2);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day2 ? date.getTime() : null;
}
function buildLearningJournal({ data, visits, accountEntries, items } = {}) {
  const byVideo = /* @__PURE__ */ new Map();
  const titleRank = /* @__PURE__ */ new Map();
  const titleTime = /* @__PURE__ */ new Map();
  function entryFor(videoId, title, rank, at = 0) {
    if (!validVideoId(videoId)) return null;
    let entry = byVideo.get(videoId);
    if (!entry) {
      entry = {
        videoId,
        title: "YouTube video",
        url: canonicalUrl$1(videoId),
        topicId: "",
        topicLabel: "",
        kind: "unknown",
        watchedSeconds: 0,
        hasPlayback: false,
        imported: false,
        visitedAt: null,
        learningStarted: false,
        hasLesson: false,
        tasks: [],
        checkedTasks: 0,
        lastActivityAt: 0
      };
      byVideo.set(videoId, entry);
    }
    const safeTitle = cleanText(title, 300);
    if (safeTitle && (rank > (titleRank.get(videoId) || 0) || rank === titleRank.get(videoId) && at > (titleTime.get(videoId) || 0))) {
      entry.title = safeTitle;
      titleRank.set(videoId, rank);
      titleTime.set(videoId, at);
    }
    return entry;
  }
  const videos = object$2(data?.videos) ? data.videos : {};
  for (const videoId of Object.keys(videos).slice(0, MAX_ROWS_PER_SOURCE)) {
    const video = videos[videoId];
    if (!validVideoId(videoId) || !object$2(video) || video.videoId != null && video.videoId !== videoId || !Number.isFinite(video.duration) || video.duration <= 0) continue;
    const ranges = mergeIntervals((Array.isArray(video.ranges) ? video.ranges : []).slice(0, MAX_ROWS_PER_SOURCE), video.duration);
    if (!ranges.length) continue;
    const entry = entryFor(videoId, video.title, 3, timestamp$1(video.updatedAt) || 0);
    entry.watchedSeconds = ranges.reduce((total, [start, end]) => total + end - start, 0);
    entry.hasPlayback = entry.watchedSeconds > 0;
    entry.lastActivityAt = timestamp$1(video.updatedAt) || 0;
  }
  for (const visit of (Array.isArray(visits) ? visits : []).slice(0, MAX_ROWS_PER_SOURCE)) {
    if (!object$2(visit) || !validVideoId(visit.videoId) || visit.url !== canonicalUrl$1(visit.videoId) || !timestamp$1(visit.lastVisitTime) || !timestamp$1(visit.importedAt)) continue;
    const entry = entryFor(visit.videoId, visit.title, 2, visit.lastVisitTime);
    entry.imported = true;
    entry.visitedAt = Math.max(entry.visitedAt || 0, visit.lastVisitTime);
    entry.lastActivityAt = Math.max(entry.lastActivityAt, visit.lastVisitTime);
  }
  for (const value of Array.isArray(accountEntries) ? accountEntries : []) {
    if (!object$2(value) || !validVideoId(value.videoId) || value.url !== canonicalUrl$1(value.videoId) || !timestamp$1(value.importedAt) || !["day", "unknown"].includes(value.datePrecision)) continue;
    const at = value.datePrecision === "day" ? historyDay(value.date) : null;
    if (value.datePrecision === "day" && at === null || value.datePrecision === "unknown" && value.date !== null) continue;
    const entry = entryFor(value.videoId, value.title, 2, at || 0);
    entry.accountHistory = true;
    entry.historyDates ||= [];
    const date = { date: value.date, dateLabel: cleanText(value.dateLabel, 100), datePrecision: value.datePrecision };
    if (!entry.historyDates.some((item) => item.date === date.date && (date.date !== null || item.dateLabel === date.dateLabel))) entry.historyDates.push(date);
    entry.historyDates.sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    entry.lastActivityAt = Math.max(entry.lastActivityAt, at || 0);
  }
  for (const item of (Array.isArray(items) ? items : []).slice(0, MAX_ROWS_PER_SOURCE)) {
    if (!object$2(item) || !validVideoId(item.videoId)) continue;
    const entry = entryFor(item.videoId, item.title, 1, timestamp$1(item.enrolledAt) || 0);
    entry.learningStarted = true;
    entry.hasLesson ||= item.hasLesson === true;
    entry.tasks = checkedTasks([...entry.tasks, ...Array.isArray(item.tasks) ? item.tasks.slice(0, MAX_ROWS_PER_SOURCE) : []]);
    entry.checkedTasks = entry.tasks.length;
    entry.lastActivityAt = Math.max(
      entry.lastActivityAt,
      timestamp$1(item.enrolledAt) || 0,
      ...entry.tasks.map((task) => Date.parse(task.checkedAt) || 0)
    );
  }
  const entries = [...byVideo.values()].map((entry) => {
    const topic = topicForVideo(entry);
    return { ...entry, topicId: topic.id, topicLabel: topic.label, kind: topic.kind };
  }).sort((a, b) => b.lastActivityAt - a.lastActivityAt || a.videoId.localeCompare(b.videoId));
  const totals = (rows) => ({
    watched: rows.filter((entry) => entry.hasPlayback).length,
    imported: rows.filter((entry) => entry.imported).length,
    learning: rows.filter((entry) => entry.learningStarted).length,
    checkedTasks: rows.reduce((total, entry) => total + entry.checkedTasks, 0)
  });
  const grouped = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    let group = grouped.get(entry.topicId);
    if (!group) {
      group = { id: entry.topicId, label: entry.topicLabel, kind: entry.kind, entries: [] };
      grouped.set(entry.topicId, group);
    }
    group.entries.push(entry);
  }
  const kindOrder = { knowledge: 0, entertainment: 1, unknown: 2 };
  const groups = [...grouped.values()].map((group) => ({ ...group, ...totals(group.entries) })).sort((a, b) => kindOrder[a.kind] - kindOrder[b.kind] || b.entries[0].lastActivityAt - a.entries[0].lastActivityAt || a.id.localeCompare(b.id));
  return { entries, groups, summary: { videos: entries.length, ...totals(entries) } };
}
const DEFAULT_ACCOUNT_HISTORY_RANGE = "latest10";
const ACCOUNT_HISTORY_IMPORT_SCOPES = Object.freeze([
  { id: "latest100", label: "Latest videos · maximum 100" },
  { id: "latest10", label: "Latest 10 videos · no scrolling" },
  { id: "all", label: "All available history" },
  { id: "week", label: "Last 7 days" },
  { id: "month", label: "Last 30 days" },
  { id: "year", label: "Last year" }
]);
const BOUNDED_HISTORY_SCOPES = Object.freeze({
  latest10: Object.freeze({ limit: 10, batchSize: 10, maxScrollRounds: 0, timeBudgetMs: 1e4 }),
  latest100: Object.freeze({ limit: 100, batchSize: 25, maxScrollRounds: 12, timeBudgetMs: 15e3 })
});
const historyImportLimit = (range) => BOUNDED_HISTORY_SCOPES[range]?.limit || null;
const ACCOUNT_HISTORY_KEY = "delta.youtube-history.v1";
const ACCOUNT_HISTORY_SESSION_KEY = "delta.youtube-history.session.v1";
const HISTORY_URL = "https://www.youtube.com/feed/history";
const RANGES = new Set(ACCOUNT_HISTORY_IMPORT_SCOPES.map((scope) => scope.id));
const PHASES = /* @__PURE__ */ new Set(["opening", "confirm", "running", "paused", "complete", "finished", "error"]);
const FINISH_REASONS = /* @__PURE__ */ new Set(["stalled", "range", "end", "timeout", "navigation", "account", "unsupported", "paused", "limit", "visible", "budget"]);
const MAX_DATE = 864e13;
const STALE_MS = 45e3;
const object$1 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const text = (value, max) => typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max) : "";
const validTime = (value, now) => Number.isFinite(value) && value > 0 && value <= now && value <= MAX_DATE;
class AccountHistoryError extends Error {
}
const fail$1 = (message) => {
  throw new AccountHistoryError(message);
};
const empty = () => ({ schemaVersion: 1, activeAccountKey: null, accounts: {} });
const canonicalUrl = (videoId) => `https://www.youtube.com/watch?v=${videoId}`;
const localDate = (time2) => {
  const date = new Date(time2);
  return `${String(date.getFullYear()).padStart(4, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};
function day(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : null;
}
function account(value) {
  if (!object$1(value) || typeof value.key !== "string" || !/^channel:@[\p{L}\p{N}\p{M}._-]{1,100}$/u.test(value.key)) return null;
  const label = text(value.label, 200);
  return label ? { key: value.key, label } : null;
}
function videoFromUrl$1(value) {
  if (typeof value !== "string" || value.length > 2048) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) || url.username || url.password || url.port) return null;
    const id = url.pathname === "/watch" && url.searchParams.getAll("v").length === 1 ? url.searchParams.get("v") : /^\/shorts\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
    return validVideoId(id) ? id : null;
  } catch {
    return null;
  }
}
function row(value, now, committed = false) {
  if (!object$1(value) || !validVideoId(value.videoId) || videoFromUrl$1(value.url) !== value.videoId || !["video", "short"].includes(value.kind)) return null;
  const date = day(value.date);
  if (value.date != null && (!date || date > localDate(now))) return null;
  if (value.datePrecision !== (date ? "day" : "unknown")) return null;
  if (committed && !validTime(value.importedAt, now)) return null;
  return {
    videoId: value.videoId,
    url: canonicalUrl(value.videoId),
    title: text(value.title, 300) || "YouTube video",
    date,
    dateLabel: text(value.dateLabel, 100) || date || "Date not shown",
    datePrecision: date ? "day" : "unknown",
    kind: value.kind,
    importedAt: committed ? value.importedAt : now,
    ...Number.isInteger(value.pageOrder) && value.pageOrder >= 0 && value.pageOrder < 100 && (!committed || validTime(value.pageObservedAt, now)) ? { pageOrder: value.pageOrder, pageObservedAt: committed ? value.pageObservedAt : now } : {}
  };
}
const rowKey = (value) => `${value.videoId}|${value.date || "unknown"}`;
function mergeRows(before, incoming) {
  const entries = new Map(before.map((value) => [rowKey(value), value]));
  for (const value of incoming) {
    const previous = entries.get(rowKey(value));
    entries.set(rowKey(value), previous ? {
      ...previous.pageOrder != null && value.pageOrder == null ? { pageOrder: previous.pageOrder, pageObservedAt: previous.pageObservedAt } : {},
      ...value,
      importedAt: Math.min(previous.importedAt, value.importedAt)
    } : value);
  }
  return [...entries.values()].sort((a, b) => (b.date || "").localeCompare(a.date || "") || a.videoId.localeCompare(b.videoId));
}
function normalizeAccountHistory(value, now = Date.now()) {
  if (!Number.isFinite(now) || now <= 0 || now > MAX_DATE) fail$1("The current date is unavailable. Saved history has not been changed.");
  const result = empty();
  if (!object$1(value) || value.schemaVersion !== 1 || !object$1(value.accounts)) return result;
  for (const [key, saved] of Object.entries(value.accounts)) {
    const identity = account(saved?.account);
    if (!identity || identity.key !== key) continue;
    const entries = [];
    for (const candidate of Array.isArray(saved.entries) ? saved.entries : []) {
      const entry = row(candidate, now, true);
      if (entry) entries.push(entry);
    }
    result.accounts[key] = { account: identity, entries: mergeRows([], entries), updatedAt: validTime(saved.updatedAt, now) ? saved.updatedAt : 0 };
  }
  result.activeAccountKey = typeof value.activeAccountKey === "string" && Object.hasOwn(result.accounts, value.activeAccountKey) ? value.activeAccountKey : null;
  return result;
}
function historyUrl(value) {
  return value === HISTORY_URL;
}
function nativeSender(api, panelSender, sender) {
  if (!sender || sender.id !== api.runtime.id || !panelSender(sender)) return false;
  try {
    const url = new URL(sender.url), root = new URL(api.runtime.getURL(""));
    return url.protocol === "chrome-extension:" && url.host === root.host && !url.username && !url.password && !url.port;
  } catch {
    return false;
  }
}
function contentSender(api, sender) {
  return sender?.id === api.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && sender.tab.id >= 0 && historyUrl(sender.url);
}
function dateRange(range, now) {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  if (range === "week") start.setDate(start.getDate() - 6);
  if (range === "month") start.setDate(start.getDate() - 29);
  if (range === "year") start.setDate(start.getDate() - 364);
  return { startDate: range === "all" || historyImportLimit(range) ? null : localDate(start.getTime()), endDate: localDate(now) };
}
function normalizeSession(value) {
  if (!object$1(value) || typeof value.id !== "string" || !/^[a-f0-9-]{36}$/.test(value.id) || !RANGES.has(value.range) || !PHASES.has(value.phase) || value.tabId !== null && (!Number.isInteger(value.tabId) || value.tabId < 0)) return null;
  return {
    id: value.id,
    tabId: value.tabId,
    phase: value.phase,
    range: value.range,
    account: account(value.account),
    startDate: day(value.startDate),
    endDate: day(value.endDate),
    message: text(value.message, 350),
    createdAt: Number.isFinite(value.createdAt) ? value.createdAt : 0,
    updatedAt: Number.isFinite(value.updatedAt) ? value.updatedAt : 0,
    lastProgressAt: Number.isFinite(value.lastProgressAt) ? value.lastProgressAt : 0,
    savedEntries: Number.isSafeInteger(value.savedEntries) && value.savedEntries >= 0 ? value.savedEntries : 0,
    skippedUnknown: Number.isSafeInteger(value.skippedUnknown) && value.skippedUnknown >= 0 ? value.skippedUnknown : 0,
    skippedOutOfRange: Number.isSafeInteger(value.skippedOutOfRange) && value.skippedOutOfRange >= 0 ? value.skippedOutOfRange : 0,
    progress: { oldestDate: day(value.progress?.oldestDate), dateLabel: text(value.progress?.dateLabel, 100) },
    ...historyImportLimit(value.range) ? { selectedVideoIds: [...new Set((Array.isArray(value.selectedVideoIds) ? value.selectedVideoIds : []).filter(validVideoId))].slice(0, historyImportLimit(value.range)) } : {},
    ...FINISH_REASONS.has(value.reason) ? { reason: value.reason } : {},
    rangeComplete: value.rangeComplete === true && value.reason === "range" && value.range !== "all",
    availablePageEnd: value.availablePageEnd === true && value.reason === "end"
  };
}
function createAccountHistoryHandler({ api, panelSender, now = Date.now, admitImports }) {
  let writes = Promise.resolve(), admission = null;
  const run = (operation) => {
    const result = writes.then(operation, operation);
    writes = result.catch(() => {
    });
    return result;
  };
  const time2 = () => {
    const value = now();
    if (!Number.isFinite(value) || value <= 0 || value > MAX_DATE) fail$1("The current date is unavailable. Saved history has not been changed.");
    return value;
  };
  const readSession = async () => normalizeSession((await api.storage.session.get(ACCOUNT_HISTORY_SESSION_KEY))[ACCOUNT_HISTORY_SESSION_KEY]);
  const saveSession = async (value) => {
    await api.storage.session.set({ [ACCOUNT_HISTORY_SESSION_KEY]: value });
    return value;
  };
  const readStore = async () => normalizeAccountHistory((await api.storage.local.get(ACCOUNT_HISTORY_KEY))[ACCOUNT_HISTORY_KEY], time2());
  async function sendTab(tabId, message) {
    let timer;
    const timeout = new Promise((_, reject2) => {
      timer = setTimeout(() => reject2(new AccountHistoryError("The YouTube history page did not respond. Import is paused.")), 8e3);
      timer.unref?.();
    });
    try {
      return await Promise.race([api.tabs.sendMessage(tabId, message, { frameId: 0 }), timeout]);
    } finally {
      clearTimeout(timer);
    }
  }
  async function stop(session) {
    if (!Number.isInteger(session?.tabId)) return;
    try {
      await sendTab(session.tabId, { type: "DELTA_ACCOUNT_HISTORY_STOP", jobId: session.id });
    } catch {
    }
  }
  async function pause(session, message, reason = "paused", phase = "paused") {
    const next = { ...session, phase, reason, rangeComplete: false, availablePageEnd: false, message, updatedAt: time2() };
    try {
      await saveSession(next);
    } finally {
      await stop(session);
    }
    return next;
  }
  async function inspectTab(session) {
    if (!Number.isInteger(session?.tabId)) fail$1("Open the YouTube history page again before continuing.");
    if (typeof api.tabs.get !== "function") return;
    let tab;
    try {
      tab = await api.tabs.get(session.tabId);
    } catch {
      fail$1("The import tab was closed. Saved history is kept. Open the history page again.");
    }
    if (tab?.url && !historyUrl(tab.url) && !(session.phase === "opening" && tab.status === "loading")) {
      fail$1("The import tab left YouTube history. Saved history is kept. Return to the history page before continuing.");
    }
  }
  async function probe(session) {
    await inspectTab(session);
    const result = await sendTab(session.tabId, { type: "DELTA_ACCOUNT_HISTORY_PROBE" });
    const identity = account(result?.account);
    if (result?.ok !== true || result.ready !== true || !identity) fail$1("Confirm that you are signed in and the YouTube history page has finished loading, then try again.");
    return identity;
  }
  async function snapshot(session) {
    const store = await readStore();
    const identity = session?.account || store.accounts[store.activeAccountKey]?.account || null;
    const saved = identity ? store.accounts[identity.key] : null;
    return {
      ok: true,
      session,
      account: identity,
      entryCount: saved?.entries.length || 0,
      videoCount: new Set((saved?.entries || []).map((entry) => entry.videoId)).size,
      accountCount: Object.keys(store.accounts).length
    };
  }
  function assertJob(message, session) {
    if (!session || message.jobId !== session.id) fail$1("This history import has changed. Refresh Delta before continuing.");
  }
  const nativeTypes = /* @__PURE__ */ new Set(["ACCOUNT_HISTORY_STATUS", "ACCOUNT_HISTORY_OPEN", "ACCOUNT_HISTORY_CONFIRM", "ACCOUNT_HISTORY_PAUSE", "ACCOUNT_HISTORY_CONTINUE", "ACCOUNT_HISTORY_CLEAR"]);
  const contentTypes = /* @__PURE__ */ new Set(["ACCOUNT_HISTORY_BATCH", "ACCOUNT_HISTORY_FINISH"]);
  const handle = async (message, sender) => {
    const native = nativeTypes.has(message?.type);
    if (native ? !nativeSender(api, panelSender, sender) : !contentTypes.has(message?.type) || !contentSender(api, sender)) {
      fail$1("This YouTube history action is not available from this page.");
    }
    if (native && admission && (message.type === "ACCOUNT_HISTORY_OPEN" || message.type === "ACCOUNT_HISTORY_PAUSE" && message.jobId === admission.jobId || message.type === "ACCOUNT_HISTORY_CLEAR" && message.accountKey === admission.accountKey)) admission.controller.abort();
    return run(async () => {
      let session = null;
      let ownedRunningRequest = false;
      let ownedNativeRequest = false;
      try {
        session = await readSession();
        if (message.type === "ACCOUNT_HISTORY_STATUS") {
          if (session?.phase === "opening") {
            try {
              const identity = await probe(session);
              session = await saveSession({ ...session, account: identity, phase: "confirm", message: "Confirm the visible YouTube account before importing.", updatedAt: time2() });
            } catch {
              if (time2() - session.createdAt > STALE_MS) session = await pause(session, "The history page is not ready. Sign in or reload it, then continue.", "timeout");
            }
          } else if (session?.phase === "running") {
            try {
              await inspectTab(session);
            } catch (error) {
              session = await pause(session, error.message, "navigation");
            }
            if (session.phase === "running" && time2() - (session.lastProgressAt || session.updatedAt) > STALE_MS) {
              session = await pause(session, "No recent collection progress was received. Saved history is kept; continue when ready.", "timeout");
            }
          }
          return await snapshot(session);
        }
        if (message.type === "ACCOUNT_HISTORY_OPEN") {
          const range = message.range ?? DEFAULT_ACCOUNT_HISTORY_RANGE;
          if (!RANGES.has(range)) fail$1("Choose latest videos (maximum 100), latest ten, all history, this week, this month or this year.");
          ownedNativeRequest = true;
          if (session && ["opening", "confirm", "running"].includes(session.phase)) await pause(session, "A new import was opened. Saved history is kept.");
          const createdAt = time2();
          session = await saveSession({
            id: crypto.randomUUID(),
            tabId: null,
            phase: "opening",
            range,
            account: null,
            ...dateRange(range, createdAt),
            createdAt,
            updatedAt: createdAt,
            lastProgressAt: 0,
            savedEntries: 0,
            skippedUnknown: 0,
            skippedOutOfRange: 0,
            progress: { oldestDate: null, dateLabel: "" },
            ...historyImportLimit(range) ? { selectedVideoIds: [] } : {},
            rangeComplete: false,
            availablePageEnd: false,
            message: "Opening YouTube history. Confirm the visible account before importing."
          });
          const tab = await api.tabs.create({ url: HISTORY_URL, active: true });
          if (!Number.isInteger(tab?.id)) fail$1("The YouTube history tab could not be opened. Please try again.");
          session = await saveSession({ ...session, tabId: tab.id });
          return await snapshot(session);
        }
        if (message.type === "ACCOUNT_HISTORY_PAUSE") {
          if (message.jobId != null) assertJob(message, session);
          ownedNativeRequest = true;
          if (session) session = await pause(session, "Import paused. Earlier saved batches are kept.");
          return await snapshot(session);
        }
        if (message.type === "ACCOUNT_HISTORY_CLEAR") {
          const store2 = await readStore();
          if (typeof message.accountKey !== "string" || message.accountKey !== store2.activeAccountKey || !Object.hasOwn(store2.accounts, message.accountKey)) {
            fail$1("Choose the currently active imported account before removing its saved history.");
          }
          ownedNativeRequest = true;
          if (session) {
            session = await pause(session, "Imported history is being removed. Collection is stopped.");
            session = await saveSession({ ...session, id: crypto.randomUUID(), account: null, message: "Imported history removed from Delta. Nothing was deleted from YouTube.", updatedAt: time2() });
          }
          delete store2.accounts[message.accountKey];
          store2.activeAccountKey = null;
          await api.storage.local.set({ [ACCOUNT_HISTORY_KEY]: store2 });
          return await snapshot(session);
        }
        if (message.type === "ACCOUNT_HISTORY_CONTINUE" || message.type === "ACCOUNT_HISTORY_CONFIRM") {
          if (message.type === "ACCOUNT_HISTORY_CONTINUE" && message.jobId == null) {
            if (!session) fail$1("Open the YouTube history page before continuing.");
          } else assertJob(message, session);
          ownedNativeRequest = true;
          if (message.type === "ACCOUNT_HISTORY_CONTINUE") session = await pause(session, "Collection stopped while the visible account is confirmed again.");
          if (message.type === "ACCOUNT_HISTORY_CONFIRM" && (session.phase !== "confirm" || message.accountKey !== session.account?.key)) {
            fail$1("Confirm the currently shown YouTube account before starting this import.");
          }
          const identity = await probe(session);
          if (session.account && identity.key !== session.account.key) {
            session = await pause(session, "The visible YouTube account changed. Open a new import for that account; existing accounts remain separate.", "account");
            fail$1("The YouTube account changed. No history was mixed between accounts.");
          }
          if (message.type === "ACCOUNT_HISTORY_CONTINUE") {
            session = await saveSession({ ...session, id: crypto.randomUUID(), account: identity, phase: "confirm", message: "Confirm the visible YouTube account again before resuming.", updatedAt: time2(), rangeComplete: false, availablePageEnd: false });
            return await snapshot(session);
          }
          const store2 = await readStore();
          store2.activeAccountKey = identity.key;
          store2.accounts[identity.key] ||= { account: identity, entries: [], updatedAt: time2() };
          store2.accounts[identity.key].account = identity;
          await api.storage.local.set({ [ACCOUNT_HISTORY_KEY]: store2 });
          session = await saveSession({
            ...session,
            account: identity,
            phase: "running",
            message: "Reading entries shown on your YouTube history page.",
            updatedAt: time2(),
            lastProgressAt: time2(),
            rangeComplete: false,
            availablePageEnd: false
          });
          const response = await sendTab(session.tabId, {
            type: "DELTA_ACCOUNT_HISTORY_START",
            jobId: session.id,
            account: identity,
            range: session.range,
            startDate: session.startDate,
            endDate: session.endDate
          });
          if (response?.ok !== true) fail$1("The YouTube history collector could not start. Earlier saved batches are kept.");
          return await snapshot(session);
        }
        assertJob(message, session);
        if (sender.tab.id !== session.tabId || session.phase !== "running") fail$1("This history import is paused or belongs to another tab.");
        ownedRunningRequest = true;
        if (message.accountKey !== session.account?.key) fail$1("The YouTube account changed. Import stopped before saving another batch.");
        if (message.type === "ACCOUNT_HISTORY_FINISH") {
          const limit2 = historyImportLimit(session.range), selectedCount = session.selectedVideoIds?.length || 0;
          if (!FINISH_REASONS.has(message.reason) || message.reason === "range" && (session.range === "all" || limit2) || message.reason === "limit" && (!limit2 || selectedCount !== limit2) || message.reason === "visible" && (session.range !== "latest10" || selectedCount >= 10) || message.reason === "budget" && (session.range !== "latest100" || selectedCount >= 100)) fail$1("The history collector returned an unverified completion state.");
          const messages = {
            limit: `Selected the first ${limit2} distinct videos shown on YouTube history${session.range === "latest10" ? " without scrolling" : ""}. Earlier saved records are kept.`,
            budget: `Stopped after the bounded scrolling budget with ${selectedCount} of at most 100 videos selected. This is a partial import; earlier saved records are kept.`,
            visible: `Selected ${session.selectedVideoIds?.length || 0} visible videos without scrolling. Fewer than 10 were available; earlier saved records are kept.`,
            range: "Reached the selected date window. Entries without verified dates were excluded.",
            end: "Reached the end currently shown on YouTube. This does not prove complete lifetime account history.",
            stalled: "No additional entries loaded. Earlier batches are saved; continue to try loading more.",
            timeout: limit2 ? `Stopped at the time limit with ${selectedCount} of at most ${limit2} videos selected. This is a partial import; earlier saved records are kept.` : "The history page stopped responding. Earlier batches are saved; continue when ready.",
            navigation: "The history page changed. Import stopped and earlier batches are saved.",
            account: "The visible account changed. Import stopped without mixing accounts.",
            unsupported: "This history layout could not be read safely. Earlier batches are saved.",
            paused: "Import paused. Earlier saved batches are kept."
          };
          session = await saveSession({
            ...session,
            phase: ["range", "end", "limit", "visible"].includes(message.reason) ? "complete" : "paused",
            reason: message.reason,
            message: messages[message.reason],
            updatedAt: time2(),
            rangeComplete: message.reason === "range",
            availablePageEnd: message.reason === "end"
          });
          await stop(session);
          return { ok: true };
        }
        if (!Array.isArray(message.rows) || message.rows.length > 500) fail$1("A history batch must contain no more than 500 visible entries.");
        const limit = historyImportLimit(session.range), bounded = Boolean(limit);
        const selected = new Set(session.selectedVideoIds || []);
        if (bounded) {
          if (message.rows.length > limit || new Set(message.rows.map((value) => value?.videoId)).size !== message.rows.length || message.rows.some((value) => !Number.isInteger(value?.pageOrder) || value.pageOrder < 0 || value.pageOrder >= limit) || new Set(message.rows.map((value) => value.pageOrder)).size !== message.rows.length) fail$1(`Latest ${limit} import accepts at most ${limit} distinct visible videos in page order.`);
          for (const value of message.rows) {
            const previousIndex = [...selected].indexOf(value.videoId);
            const expected = previousIndex < 0 ? selected.size : previousIndex;
            if (value.pageOrder !== expected) fail$1(`Latest ${limit} import must preserve the selected visible page order.`);
            selected.add(value.videoId);
          }
          if (selected.size > limit) fail$1(`Latest ${limit} import cannot add more than ${limit} distinct videos.`);
        }
        const currentTime = time2(), candidates = [];
        let skippedUnknown = 0, skippedOutOfRange = 0;
        for (const candidate of message.rows) {
          const entry = row(candidate, currentTime);
          if (!entry) fail$1("A history entry could not be verified. Import paused before saving this batch.");
          if (session.range !== "all" && !bounded && !entry.date) {
            skippedUnknown++;
            continue;
          }
          if (session.range !== "all" && !bounded && (entry.date < session.startDate || entry.date > session.endDate)) {
            skippedOutOfRange++;
            continue;
          }
          candidates.push(entry);
        }
        if (candidates.length) {
          const controller = new AbortController();
          admission = { controller, tabId: session.tabId, jobId: session.id, accountKey: session.account.key };
          try {
            await admitImportBatch(admitImports, session.id, candidates.map((value) => value.videoId), controller.signal);
          } catch (error) {
            fail$1(importAdmissionMessage(error));
          }
          const current = await readSession(), identity = await probe(session);
          if (current?.id !== session.id || current.phase !== "running" || identity.key !== session.account.key) fail$1("The visible account changed. Import stopped without mixing accounts.");
        }
        const store = await readStore();
        const saved = store.accounts[session.account.key] || { account: session.account, entries: [], updatedAt: 0 };
        const entries = candidates.length ? mergeRows(saved.entries, candidates) : saved.entries;
        if (admission?.controller.signal.aborted) fail$1("Import stopped. Your saved records are kept.");
        if (candidates.length && JSON.stringify(entries) !== JSON.stringify(saved.entries)) {
          store.activeAccountKey = session.account.key;
          store.accounts[session.account.key] = { account: session.account, entries, updatedAt: currentTime };
          await api.storage.local.set({ [ACCOUNT_HISTORY_KEY]: store });
        }
        const added = entries.length - saved.entries.length;
        session = await saveSession({
          ...session,
          updatedAt: currentTime,
          lastProgressAt: currentTime,
          savedEntries: session.savedEntries + added,
          skippedUnknown: session.skippedUnknown + skippedUnknown,
          skippedOutOfRange: session.skippedOutOfRange + skippedOutOfRange,
          ...bounded ? { selectedVideoIds: [...selected] } : {},
          progress: { oldestDate: day(message.progress?.oldestDate), dateLabel: text(message.progress?.dateLabel, 100) }
        });
        return { ok: true, added, entryCount: entries.length };
      } catch (error) {
        if (session && (ownedRunningRequest || ownedNativeRequest)) {
          try {
            await pause(session, error instanceof AccountHistoryError ? error.message : "Import paused because this batch could not be saved. Earlier saved history is kept.");
          } catch {
          }
        }
        if (error instanceof AccountHistoryError) throw error;
        throw new AccountHistoryError("YouTube history import could not be completed. Earlier saved history is kept. Please try again.");
      } finally {
        admission = null;
      }
    });
  };
  handle.handleTabRemoved = (tabId) => {
    if (admission?.tabId === tabId) admission.controller.abort();
    return run(async () => {
      const session = await readSession();
      if (session?.tabId === tabId && ["opening", "confirm", "running"].includes(session.phase)) await pause(session, "The import tab was closed. Earlier saved history is kept.", "navigation");
    });
  };
  handle.handleTabUpdated = (tabId, url) => {
    if (admission?.tabId === tabId && !historyUrl(url)) admission.controller.abort();
    return run(async () => {
      const session = await readSession();
      if (session?.tabId === tabId && typeof url === "string" && !historyUrl(url) && ["confirm", "running"].includes(session.phase)) {
        await pause(session, "The import tab left YouTube history. Earlier saved history is kept.", "navigation");
      }
    });
  };
  return handle;
}
const LEARNING_LIBRARY_KEY = "delta.learning.library.v1";
const PANEL_INTENT_KEY = "delta.learning.panel-intent.v1";
const pilotTitle = "How to use SUMIF and SUMIFS in Microsoft Excel";
const normalize = (value) => ({
  schemaVersion: 1,
  items: Object.fromEntries(Object.entries(value?.items || {}).filter(([id]) => id === LEARNING_PILOT.videoId).map(([id, item]) => [id, {
    videoId: id,
    title: typeof item?.title === "string" ? item.title.slice(0, 300) : pilotTitle,
    enrolledAt: Number.isFinite(item?.enrolledAt) ? item.enrolledAt : 0
  }])),
  dismissed: [...new Set((Array.isArray(value?.dismissed) ? value.dismissed : []).filter(validVideoId))].slice(-1e3)
});
async function learningEntryState(storage, videoId) {
  if (!validVideoId(videoId)) return { learningDismissed: false, learningEnrolled: false };
  const key = `${LEARNING_STORE_PREFIX}${videoId}`;
  const saved = await storage.get(LEARNING_LIBRARY_KEY);
  const library = normalize(saved[LEARNING_LIBRARY_KEY]);
  const workspace = videoId === LEARNING_PILOT.videoId ? (await storage.get(key))[key]?.value : null;
  return {
    learningDismissed: library.dismissed.includes(videoId),
    learningEnrolled: Boolean(library.items[videoId] || workspace?.lesson)
  };
}
function createLearningLibrary({ api, repository, readEndpoint, panelSender, contentSender: contentSender2, now = Date.now }) {
  let writes = Promise.resolve();
  const serialize = (operation) => {
    const result = writes.then(operation, operation);
    writes = result.catch(() => {
    });
    return result;
  };
  function authorize(sender, videoId, nativeOnly = false) {
    if (!panelSender(sender) && (nativeOnly || !contentSender2(sender))) throw Error("This action is only available in Delta.");
    if (videoId !== void 0 && (!validVideoId(videoId) || contentSender2(sender) && youtubeVideoId(sender.url) !== videoId)) {
      throw Error("Use the current YouTube video for this action.");
    }
  }
  async function list(sender) {
    authorize(sender, void 0, true);
    const endpoint = await readEndpoint();
    const library = normalize((await api.storage.local.get(LEARNING_LIBRARY_KEY))[LEARNING_LIBRARY_KEY]);
    const key = `${LEARNING_STORE_PREFIX}${LEARNING_PILOT.videoId}`;
    const workspace = (await api.storage.local.get(key))[key];
    if (workspace?.value?.lesson && !library.items[LEARNING_PILOT.videoId]) library.items[LEARNING_PILOT.videoId] = {
      videoId: LEARNING_PILOT.videoId,
      title: pilotTitle,
      enrolledAt: 0
    };
    const record = normalizeSkills((await api.storage.local.get(SKILLS_STORE_KEY))[SKILLS_STORE_KEY]?.value);
    const tasks = record.evidence.filter((e) => e.origin === endpoint).map((e) => ({ taskId: e.taskId, total: e.actualTotal, checkedAt: e.checkedAt, formula: e.formula }));
    const items = Object.values(library.items).map((item) => ({
      ...item,
      url: `https://www.youtube.com/watch?v=${item.videoId}&t=35s`,
      hasLesson: Boolean(workspace?.endpoint === endpoint && workspace.value?.lesson),
      tasks
    }));
    const data = await repository.read();
    const imported = normalizeImportedHistory((await api.storage.local.get(HISTORY_IMPORT_KEY))[HISTORY_IMPORT_KEY], now());
    const accountHistory = normalizeAccountHistory((await api.storage.local.get(ACCOUNT_HISTORY_KEY))[ACCOUNT_HISTORY_KEY], now());
    const activeHistory = accountHistory.accounts[accountHistory.activeAccountKey];
    const journalItems = items.length || !tasks.length ? items : [{ videoId: LEARNING_PILOT.videoId, title: pilotTitle, hasLesson: false, tasks }];
    return { ok: true, endpoint, items, journal: { ...buildLearningJournal({
      data,
      visits: imported.visits,
      items: journalItems,
      accountEntries: activeHistory?.entries || []
    }), account: activeHistory?.account || null } };
  }
  async function enrol(videoId, sender) {
    authorize(sender, videoId);
    if (videoId !== LEARNING_PILOT.videoId) throw Error("Use the supported SUMIF video to start this saved lesson.");
    return serialize(async () => {
      const data = await repository.read();
      const library = normalize((await api.storage.local.get(LEARNING_LIBRARY_KEY))[LEARNING_LIBRARY_KEY]);
      if (!library.items[videoId]) {
        library.items[videoId] = { videoId, title: data.videos[videoId]?.title || pilotTitle, enrolledAt: now() };
        await api.storage.local.set({ [LEARNING_LIBRARY_KEY]: library });
      }
      return { ok: true };
    });
  }
  async function dismiss(videoId, sender) {
    authorize(sender, videoId);
    return serialize(async () => {
      const library = normalize((await api.storage.local.get(LEARNING_LIBRARY_KEY))[LEARNING_LIBRARY_KEY]);
      if (!library.dismissed.includes(videoId)) {
        library.dismissed = [...library.dismissed, videoId].slice(-1e3);
        await api.storage.local.set({ [LEARNING_LIBRARY_KEY]: library });
      }
      return { ok: true };
    });
  }
  return { list, enrol, dismiss };
}
const HOSTED_ACTIONS_KEY = "delta.hosted-actions.v1";
const HOSTED_ACTION_TTL_MS = 6e5;
const requestIdValid = (value) => typeof value === "string" && /^[A-Za-z0-9_-]{16,80}$/.test(value);
function hostedActionResultKey(requestId) {
  if (!requestIdValid(requestId)) throw Error("Invalid hosted request.");
  return `delta.hosted-action.result.v1:${requestId}`;
}
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const fail = () => {
  throw Error("This hosted action is not available from this page.");
};
function sourceId(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === "www.youtube.com" && url.pathname === "/watch" && !url.username && !url.password && !url.port && url.searchParams.getAll("v").length === 1 && validVideoId(url.searchParams.get("v")) ? url.searchParams.get("v") : null;
  } catch {
    return null;
  }
}
function hostedEndpoint(value) {
  const endpoint = normalizeApiEndpoint(value), url = new URL(endpoint);
  if (endpoint !== DEFAULT_API_ENDPOINT && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) throw Error("Use the Delta production website or an explicit local development service.");
  return endpoint;
}
function classificationPayload(payload) {
  if (!object(payload) || !Array.isArray(payload.videos) || payload.videos.length < 1 || payload.videos.length > 12) throw Error("Analyze between one and twelve videos per batch.");
  const videos = metadataForMap(payload.videos);
  if (videos.length !== payload.videos.length || new Set(videos.map((value) => value.videoId)).size !== videos.length) throw Error("Use distinct videos with valid titles.");
  const existingPaths = payload.existingPaths ?? [];
  if (!Array.isArray(existingPaths) || existingPaths.length > 80 || existingPaths.some((path) => !Array.isArray(path) || path.length < 1 || path.length > 4 || !path.every(validMapLabel))) throw Error("The existing topic paths are invalid.");
  const result = { videos, existingPaths: existingPaths.map((path) => path.map((label) => label.normalize("NFC").replace(/\s+/g, " "))) };
  if (new TextEncoder().encode(JSON.stringify(result)).length > 4e4) throw Error("This metadata batch is too large.");
  return result;
}
function capturedSource(value, videoId) {
  if (!object(value) || value.videoId !== videoId || sourceId(value.url) !== videoId || typeof value.title !== "string" || !value.title.trim() || value.title.length > 400 || typeof value.transcript !== "string" || !value.transcript.trim() || new TextEncoder().encode(value.transcript).length > 25e4 || !Number.isFinite(value.start) || !Number.isFinite(value.end) || value.start < 0 || value.end > 86400 || value.end <= value.start || value.end - value.start > 300) throw Error("The captured captions did not match the selected video. Reopen its transcript and try again.");
  return { videoId, title: value.title.slice(0, 300), url: `https://www.youtube.com/watch?v=${videoId}`, start: value.start, end: value.end, transcript: value.transcript };
}
function createHostedActionBroker({ api, readEndpoint, panelSender, now = Date.now, randomId = () => crypto.randomUUID().replaceAll("-", "") } = {}) {
  let chain = Promise.resolve();
  const serial = (operation) => {
    const next = chain.catch(() => {
    }).then(operation);
    chain = next;
    return next;
  };
  const persist = (state) => api.storage.session.set({ [HOSTED_ACTIONS_KEY]: state });
  async function read() {
    const saved = (await api.storage.session.get(HOSTED_ACTIONS_KEY))[HOSTED_ACTIONS_KEY];
    const state = saved?.schemaVersion === 1 && object(saved.pending) && object(saved.results) ? saved : { schemaVersion: 1, pending: {}, results: {} };
    let changed = false;
    for (const [id, expiresAt] of Object.entries(state.results)) if (!Number.isFinite(expiresAt) || expiresAt <= now()) {
      delete state.results[id];
      await api.storage.session.remove(hostedActionResultKey(id));
      changed = true;
    }
    for (const [nonce, pending] of Object.entries(state.pending)) if (!Number.isFinite(pending.expiresAt) || pending.expiresAt <= now()) {
      delete state.pending[nonce];
      if (["classify", "imports"].includes(pending.action)) await finish(state, pending, "cancelled", null, "This action expired. Open it again from Delta.");
      changed = true;
    }
    if (changed) await persist(state);
    return state;
  }
  async function finish(state, pending, status, result = null, error = "", details = {}) {
    delete state.pending[pending.nonce];
    if (!["classify", "imports"].includes(pending.action)) return;
    const ids = Object.keys(state.results);
    while (ids.length >= 16) {
      const id = ids.shift();
      delete state.results[id];
      await api.storage.session.remove(hostedActionResultKey(id));
    }
    state.results[pending.requestId] = now() + HOSTED_ACTION_TTL_MS;
    const httpStatus = [400, 401, 402, 403, 409, 422, 429, 500, 503, 504].includes(details.status) ? details.status : null;
    const code = [402, 429].includes(httpStatus) ? "QUOTA" : [401, 403].includes(httpStatus) ? "AUTH_REQUIRED" : status === "cancelled" ? "CANCELLED" : "HOSTED_UNAVAILABLE";
    await api.storage.session.set({ [hostedActionResultKey(pending.requestId)]: { requestId: pending.requestId, action: pending.action, status, endpoint: pending.endpoint, ...result ? { result } : {}, ...error ? { error, code, ...httpStatus ? { httpStatus } : {} } : {}, at: now() } });
  }
  function internalSender(sender) {
    return sender?.id === api.runtime.id && panelSender(sender);
  }
  async function waitForYouTube(tab) {
    if (tab.status === "complete" || !api.tabs.onUpdated?.addListener) return;
    await new Promise((resolve) => {
      let complete = false;
      const stop = () => {
        if (complete) return;
        complete = true;
        clearTimeout(timer);
        api.tabs.onUpdated.removeListener?.(listener);
        resolve();
      };
      const listener = (id, change) => {
        if (id === tab.id && change.status === "complete") stop();
      };
      const timer = setTimeout(stop, 15e3);
      api.tabs.onUpdated.addListener(listener);
      api.tabs.get(tab.id).then((value) => {
        if (value?.status === "complete") stop();
      }, stop);
    });
  }
  async function capture(tabId, message) {
    let timer;
    try {
      return await Promise.race([api.tabs.sendMessage(tabId, message), new Promise((resolve) => {
        timer = setTimeout(() => resolve(null), 15e3);
      })]);
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }
  async function open(message) {
    const endpoint = hostedEndpoint(await readEndpoint());
    if (message.endpoint && message.endpoint !== endpoint) throw Error("The service changed. Open the action again.");
    if (!requestIdValid(message.requestId) || !["learn", "classify", "imports"].includes(message.action)) throw Error("Invalid hosted action.");
    const state = await read();
    if (Object.keys(state.pending).length >= 8) throw Error("Finish or close another pending Delta action first.");
    if (Object.values(state.pending).some((value) => value.requestId === message.requestId) || state.results[message.requestId]) throw Error("This action has already been opened.");
    let payload;
    if (message.action === "imports") payload = importPayload(message.payload);
    else if (message.action === "classify") payload = classificationPayload(message.payload);
    else {
      if (message.videoId != null && !validVideoId(message.videoId)) throw Error("Open a YouTube video before learning.");
      const matching = (value) => Number.isInteger(value?.id) && sourceId(value.url) && (!message.videoId || sourceId(value.url) === message.videoId);
      const tabs = Number.isInteger(message.tabId) ? [await api.tabs.get(message.tabId)] : await api.tabs.query({ active: true, lastFocusedWindow: true });
      let tab2 = tabs.find(matching);
      if (!tab2 && !Number.isInteger(message.tabId) && message.videoId) {
        tab2 = (await api.tabs.query({ url: "https://www.youtube.com/watch*" })).find(matching);
        if (!tab2) {
          tab2 = await api.tabs.create({ url: `https://www.youtube.com/watch?v=${message.videoId}` });
          if (Number.isInteger(tab2?.id)) {
            await waitForYouTube(tab2);
            tab2 = await api.tabs.get(tab2.id);
          }
        }
      }
      if (!tab2) throw Error("Open the matching YouTube video before learning.");
      const videoId = sourceId(tab2.url);
      const intent = (await api.storage.session.get(PANEL_INTENT_KEY))[PANEL_INTENT_KEY];
      if (intent?.tabId === tab2.id && intent.videoId === videoId) await api.storage.session.remove(PANEL_INTENT_KEY);
      if (message.start != null && !Number.isFinite(message.start) || message.end != null && !Number.isFinite(message.end)) throw Error("Use a valid caption clip.");
      if (message.start != null && message.start < 0 || message.end != null && (message.end > 86400 || message.end < 0) || message.start != null && message.end != null && (message.end <= message.start || message.end - message.start > 300)) throw Error("Choose a caption clip of up to five minutes.");
      const captured = await capture(tab2.id, { type: "DELTA_CAPTURE_TRANSCRIPT", videoId, ...message.start != null ? { start: message.start } : {}, ...message.end != null ? { end: message.end } : {} });
      payload = captured?.ok ? capturedSource(captured, videoId) : { videoId, title: typeof tab2.title === "string" ? tab2.title.slice(0, 300) : "YouTube video", url: `https://www.youtube.com/watch?v=${videoId}`, captureError: "Captions were unavailable. Open the video transcript on YouTube, then try again. Prepared sources and manual caption import remain available." };
    }
    const nonce = randomId();
    if (typeof nonce !== "string" || !/^[a-f0-9]{32}$/.test(nonce)) throw Error("The secure action could not be created.");
    const tab = await api.tabs.create({ url: "about:blank" });
    if (!Number.isInteger(tab?.id)) throw Error("The learning website could not be opened.");
    const pending = { nonce, requestId: message.requestId, action: message.action, endpoint, tabId: tab.id, payload, createdAt: now(), expiresAt: now() + HOSTED_ACTION_TTL_MS };
    state.pending[nonce] = pending;
    await persist(state);
    const url = new URL("/learn", endpoint);
    url.searchParams.set("hosted", "1");
    url.searchParams.set("extension", api.runtime.id);
    url.searchParams.set("request", nonce);
    if (message.action === "learn") url.searchParams.set("videoId", payload.videoId);
    try {
      await api.tabs.update(tab.id, { url: url.href });
    } catch {
      await finish(state, pending, "error", null, "The learning website could not be opened.");
      await persist(state);
      throw Error("The learning website could not be opened.");
    }
    return { ok: true, action: message.action, opened: true, requestId: message.requestId, nonce, tabId: tab.id };
  }
  async function handleInternal(message, sender) {
    if (!internalSender(sender)) fail();
    return serial(async () => {
      if (message?.type === "DELTA_HOSTED_ACTION_OPEN") return open(message);
      if (message?.type === "DELTA_HOSTED_ACTION_CANCEL") {
        if (!requestIdValid(message.requestId)) fail();
        const state = await read();
        const pending = Object.values(state.pending).find((value) => value.requestId === message.requestId);
        if (pending) {
          await finish(state, pending, "cancelled", null, pending.action === "imports" ? "History import stopped. Your existing saved records are kept." : "Map analysis stopped. Your records are saved.");
          await persist(state);
        }
        return { ok: true };
      }
      fail();
    });
  }
  async function handleExternal(message, sender) {
    return serial(async () => {
      if (sender?.id || sender?.frameId !== 0 || !Number.isInteger(sender?.tab?.id) || typeof message?.requestId !== "string" || !/^[a-f0-9]{32}$/.test(message.requestId)) fail();
      const state = await read(), pending = state.pending[message.requestId];
      if (!pending || pending.tabId !== sender.tab.id) fail();
      let url;
      try {
        url = new URL(sender.url);
      } catch {
        fail();
      }
      if (url.origin !== pending.endpoint || sender.origin != null && sender.origin !== pending.endpoint || url.pathname !== "/learn" || url.searchParams.get("hosted") !== "1" || url.searchParams.get("request") !== pending.nonce || url.searchParams.get("extension") !== api.runtime.id) fail();
      if (message.type === "DELTA_HOSTED_ACTION_GET") return { ok: true, action: pending.action, requestId: pending.nonce, expiresAt: pending.expiresAt, payload: pending.payload };
      if (message.type === "DELTA_HOSTED_ACTION_RESULT" && ["classify", "imports"].includes(pending.action)) {
        const result = pending.action === "imports" ? importReceipt(message.result, pending.payload) : validateMapAnalysisResponse(message.result, pending.payload.videos);
        await finish(state, pending, "complete", result);
        await persist(state);
        return { ok: true };
      }
      if (message.type === "DELTA_HOSTED_ACTION_ERROR" && ["classify", "imports"].includes(pending.action)) {
        const messageText = pending.action === "imports" ? message.status === 402 ? "This selection exceeds your remaining history allowance. Choose fewer videos; check Starter Pack availability in the Learning lab. Saved records remain available." : "Import registration did not finish. Your saved records are kept. Return to Delta and try again." : message.status === 429 ? "Your free AI allowance or the model quota is unavailable. Your records are saved." : "Map analysis did not finish. Your records are saved. Return to Delta and try again.";
        await finish(state, pending, "error", null, messageText, { status: message.status });
        await persist(state);
        return { ok: true };
      }
      fail();
    });
  }
  async function handleTabRemoved(tabId) {
    return serial(async () => {
      const state = await read();
      for (const pending of Object.values(state.pending)) if (pending.tabId === tabId) await finish(state, pending, "cancelled", null, "The learning website was closed. Your existing saved records are kept.");
      await persist(state);
    });
  }
  return { handleInternal, handleExternal, handleTabRemoved };
}
const issue = (message, code = "HOSTED_UNAVAILABLE", status = null) => Object.assign(Error(message), { code, ...status ? { status } : {} });
function openHostedAction({ action, payload, videoId, tabId, start, end, endpoint, signal, onStatus } = {}, { api = globalThis.chrome, timeoutMs = HOSTED_ACTION_TTL_MS } = {}) {
  const stopped = action === "imports" ? "History import stopped. Your existing saved records are kept." : "Map analysis stopped. Your records are saved.";
  if (signal?.aborted) return Promise.reject(issue(stopped, "CANCELLED"));
  if (!api?.runtime?.sendMessage || !api?.storage?.session || !api?.storage?.onChanged) return Promise.reject(Error("Open this action from the Delta extension."));
  const requestId = crypto.randomUUID(), key = hostedActionResultKey(requestId);
  return new Promise((resolve, reject2) => {
    let finished = false, timer;
    function settle(error, result2) {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      api.storage.onChanged.removeListener(changed);
      void api.storage.session.remove(key).catch(() => {
      });
      if (error) reject2(error);
      else resolve(result2);
    }
    const notify = (status) => {
      try {
        onStatus?.(status);
      } catch {
      }
    };
    function result(value) {
      if (!value || value.requestId !== requestId || value.action !== action) return;
      if (value.status === "complete") {
        notify("complete");
        settle(null, value.result);
      } else if (["error", "cancelled"].includes(value.status)) settle(issue(value.error || stopped, ["QUOTA", "AUTH_REQUIRED", "CANCELLED", "HOSTED_UNAVAILABLE"].includes(value.code) ? value.code : "HOSTED_UNAVAILABLE", [401, 402, 403, 429, 500, 503, 504].includes(value.httpStatus) ? value.httpStatus : null));
    }
    function changed(changes, area) {
      if (area === "session" && changes[key]?.newValue) result(changes[key].newValue);
    }
    function abort() {
      cancel("CANCELLED");
    }
    function cancel(code) {
      void api.runtime.sendMessage({ type: "DELTA_HOSTED_ACTION_CANCEL", requestId }).catch(() => {
      });
      settle(issue(code === "TIMEOUT" ? action === "imports" ? "History import timed out. Your existing saved records are kept." : "Map analysis timed out. Your records are saved." : stopped, code));
    }
    api.storage.onChanged.addListener(changed);
    signal?.addEventListener("abort", abort, { once: true });
    timer = setTimeout(() => cancel("TIMEOUT"), Number.isFinite(timeoutMs) && timeoutMs > 0 ? Math.min(timeoutMs, HOSTED_ACTION_TTL_MS) : HOSTED_ACTION_TTL_MS);
    notify(action === "learn" ? "capturing" : "opening");
    Promise.resolve(api.runtime.sendMessage({ type: "DELTA_HOSTED_ACTION_OPEN", action, requestId, ...payload ? { payload } : {}, ...videoId ? { videoId } : {}, ...tabId != null ? { tabId } : {}, ...start != null ? { start } : {}, ...end != null ? { end } : {}, ...endpoint ? { endpoint } : {} })).then(async (response) => {
      if (finished) {
        if (response?.ok) void api.runtime.sendMessage({ type: "DELTA_HOSTED_ACTION_CANCEL", requestId }).catch(() => {
        });
        return;
      }
      if (!response?.ok) throw Error(response?.error || "The learning website could not be opened.");
      if (action === "learn") {
        notify("opening");
        settle(null, response);
        return;
      }
      notify("waiting");
      result((await api.storage.session.get(key))[key]);
    }).catch((error) => settle(error));
  });
}
const hostedActionClient = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  openHostedAction
}, Symbol.toStringTag, { value: "Module" }));
function createImportAdmission({ api, broker }) {
  const bridgeApi = { storage: api.storage, runtime: { sendMessage: (message) => broker.handleInternal(
    message,
    { id: api.runtime.id, url: api.runtime.getURL("background.js") }
  ) } };
  return (payload, { signal } = {}) => openHostedAction({ action: "imports", payload, signal }, { api: bridgeApi });
}
async function admitImportBatch(admitImports, jobId, videoIds, signal) {
  if (typeof admitImports !== "function") throw Error("Sign in through the Delta website to verify your import allowance. Your saved records are kept.");
  const ids = [...new Set(videoIds)], encoded = new TextEncoder().encode([...ids].sort().join("\0"));
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoded)), (v) => v.toString(16).padStart(2, "0")).join("");
  const payload = importPayload({ operationId: `${jobId}_${digest}`, videoIds: ids });
  const result = importReceipt(await admitImports(payload, { signal }), payload);
  if (signal.aborted) throw Object.assign(Error("Import stopped. Your saved records are kept."), { code: "CANCELLED" });
  return result;
}
function importAdmissionMessage(error) {
  if (["QUOTA", "CANCELLED", "AUTH_REQUIRED", "HOSTED_UNAVAILABLE", "TIMEOUT"].includes(error?.code)) return String(error.message).slice(0, 300);
  return "Import allowance could not be verified. Open the Delta website and sign in, then try again. Your saved records are kept.";
}
const HISTORY_IMPORT_KEY = "delta.history.imported.v1";
const HISTORY_PREVIEW_KEY = "delta.history.preview.v1";
const DAY_MS = 864e5;
const PREVIEW_TTL_MS = 10 * 6e4;
const MAX_QUERY_RESULTS = 1e3;
const MAX_PREVIEW_ROWS = 200;
const MAX_IMPORTED_ROWS = 1e3;
const HISTORY_PERMISSION = Object.freeze({ permissions: ["history"] });
const YOUTUBE_HOSTS = /* @__PURE__ */ new Set(["youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"]);
const MESSAGE_TYPES = /* @__PURE__ */ new Set(["HISTORY_STATUS", "HISTORY_PREVIEW", "HISTORY_IMPORT", "HISTORY_CANCEL", "HISTORY_CLEAR", "HISTORY_DISCONNECT"]);
class HistoryImportError extends Error {
}
const reject = (message) => {
  throw new HistoryImportError(message);
};
function timestamp(value, currentTime) {
  return typeof value === "number" && Number.isFinite(value) && value > 0 && value <= currentTime ? value : null;
}
function videoFromUrl(value) {
  if (typeof value !== "string" || value.length > 2048) return null;
  try {
    const url = new URL(value);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password || url.port) return null;
    let videoId = null;
    if (YOUTUBE_HOSTS.has(url.hostname)) {
      if (url.pathname === "/watch" && url.searchParams.getAll("v").length === 1) videoId = url.searchParams.get("v");
      else videoId = /^\/(?:shorts|live)\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
    } else if (url.hostname === "youtu.be") videoId = /^\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
    return validVideoId(videoId) ? videoId : null;
  } catch {
    return null;
  }
}
function cleanVisit(value, currentTime, { startTime = 0, committed = false } = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const videoId = videoFromUrl(value.url);
  const lastVisitTime = timestamp(value.lastVisitTime, currentTime);
  if (!videoId || value.videoId != null && value.videoId !== videoId || !lastVisitTime || lastVisitTime < startTime) return null;
  const title = typeof value.title === "string" ? value.title.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 300) : "";
  const visit = { videoId, url: `https://www.youtube.com/watch?v=${videoId}`, title: title || "YouTube video", lastVisitTime };
  if (committed) {
    const importedAt = timestamp(value.importedAt, currentTime);
    if (!importedAt) return null;
    visit.importedAt = importedAt;
  }
  return visit;
}
function cleanVisits(values, currentTime, options = {}) {
  const byVideo = /* @__PURE__ */ new Map();
  if (!Array.isArray(values)) return [];
  for (const value of values.slice(0, MAX_QUERY_RESULTS * 2)) {
    const visit = cleanVisit(value, currentTime, options);
    if (!visit) continue;
    const previous = byVideo.get(visit.videoId);
    if (!previous || visit.lastVisitTime > previous.lastVisitTime) byVideo.set(visit.videoId, visit);
  }
  return [...byVideo.values()].sort((a, b) => b.lastVisitTime - a.lastVisitTime || a.videoId.localeCompare(b.videoId));
}
function normalizeImportedHistory(value, currentTime = Date.now()) {
  if (!value || value.schemaVersion !== 1) return { visits: [], updatedAt: null };
  return {
    visits: cleanVisits(value.visits, currentTime, { committed: true }).slice(0, MAX_IMPORTED_ROWS),
    updatedAt: timestamp(value.updatedAt, currentTime)
  };
}
function trustedPanel(api, panelSender, sender) {
  if (!sender || sender.id !== api.runtime.id || typeof panelSender !== "function" || !panelSender(sender)) return false;
  try {
    const url = new URL(sender.url), extension = new URL(api.runtime.getURL(""));
    return url.protocol === "chrome-extension:" && url.host === extension.host && !url.username && !url.password && !url.port;
  } catch {
    return false;
  }
}
function createHistoryImportHandler({ api, panelSender, now = Date.now, admitImports }) {
  let writes = Promise.resolve(), admission = null;
  const run = (operation) => {
    const result = writes.then(operation, operation);
    writes = result.catch(() => {
    });
    return result;
  };
  const currentTime = () => {
    const value = now();
    if (!Number.isFinite(value) || value <= 0 || value > 864e13) reject("The current time is unavailable. Please try again.");
    return value;
  };
  const granted = async () => Boolean(await api.permissions.contains(HISTORY_PERMISSION));
  const clearPreview = async () => api.storage.session.remove(HISTORY_PREVIEW_KEY);
  const requirePermission = async () => {
    if (await granted()) return;
    await clearPreview();
    reject("Chrome history access is off. You can continue learning without importing.");
  };
  const status = async () => {
    const permission = await granted();
    if (!permission) await clearPreview();
    const value = (await api.storage.local.get(HISTORY_IMPORT_KEY))[HISTORY_IMPORT_KEY];
    return { ok: true, granted: permission, ...normalizeImportedHistory(value, currentTime()) };
  };
  return async function handleHistoryImport(message, sender) {
    if (!trustedPanel(api, panelSender, sender)) reject("History import is available only in the Delta extension panel.");
    if (!MESSAGE_TYPES.has(message?.type)) reject("This history import action is not supported.");
    if (["HISTORY_CANCEL", "HISTORY_CLEAR", "HISTORY_DISCONNECT", "HISTORY_PREVIEW"].includes(message.type)) admission?.abort();
    return run(async () => {
      try {
        if (message.type === "HISTORY_STATUS") return await status();
        if (message.type === "HISTORY_CANCEL") {
          await clearPreview();
          return { ok: true };
        }
        if (message.type === "HISTORY_CLEAR") {
          await clearPreview();
          await api.storage.local.remove(HISTORY_IMPORT_KEY);
          return await status();
        }
        if (message.type === "HISTORY_DISCONNECT") {
          await api.permissions.remove(HISTORY_PERMISSION);
          await clearPreview();
          if (await granted()) reject("Chrome history access could not be disconnected. Please try again.");
          return await status();
        }
        if (message.type === "HISTORY_PREVIEW") {
          if (![7, 30, 90].includes(message.days)) reject("Choose a history range of 7, 30 or 90 days.");
          await requirePermission();
          await clearPreview();
          const endTime = currentTime(), startTime = Math.max(0, endTime - message.days * DAY_MS);
          const results = await Promise.all(["youtube.com", "youtu.be"].map((text2) => api.history.search({ text: text2, startTime, endTime, maxResults: MAX_QUERY_RESULTS })));
          if (results.some((items) => !Array.isArray(items) || items.length > MAX_QUERY_RESULTS)) reject("Chrome returned an invalid history response. Please try again.");
          await requirePermission();
          const rows = cleanVisits(results.flat(), endTime, { startTime });
          const visits2 = rows.slice(0, MAX_PREVIEW_ROWS);
          const token = globalThis.crypto.randomUUID();
          const truncated = rows.length > MAX_PREVIEW_ROWS || results.some((items) => items.length === MAX_QUERY_RESULTS);
          await api.storage.session.set({ [HISTORY_PREVIEW_KEY]: {
            schemaVersion: 1,
            token,
            owner: typeof sender.documentId === "string" ? sender.documentId : null,
            createdAt: endTime,
            expiresAt: endTime + PREVIEW_TTL_MS,
            days: message.days,
            visits: visits2,
            truncated
          } });
          return { ok: true, token, visits: visits2, truncated, days: message.days };
        }
        await requirePermission();
        const time2 = currentTime();
        const preview = (await api.storage.session.get(HISTORY_PREVIEW_KEY))[HISTORY_PREVIEW_KEY];
        if (!preview || preview.schemaVersion !== 1 || typeof message.token !== "string" || message.token !== preview.token || (preview.owner ?? null) !== (typeof sender.documentId === "string" ? sender.documentId : null) || !timestamp(preview.createdAt, time2) || preview.expiresAt !== preview.createdAt + PREVIEW_TTL_MS || time2 >= preview.expiresAt || ![7, 30, 90].includes(preview.days)) {
          await clearPreview();
          reject("This history preview has expired or changed. Preview your visits again.");
        }
        if (!Array.isArray(message.videoIds) || !message.videoIds.length || message.videoIds.length > 100 || message.videoIds.some((videoId) => !validVideoId(videoId))) reject("Choose valid videos from the current history preview.");
        const previewRows = cleanVisits(preview.visits, preview.createdAt, { startTime: Math.max(0, preview.createdAt - preview.days * DAY_MS) }).slice(0, MAX_PREVIEW_ROWS);
        const selected = new Set(message.videoIds);
        if ([...selected].some((videoId) => !previewRows.some((visit) => visit.videoId === videoId))) reject("The selection does not match this history preview. Preview your visits again.");
        const controller = new AbortController();
        admission = controller;
        try {
          await admitImportBatch(admitImports, preview.token, [...selected], controller.signal);
        } catch (error) {
          reject(importAdmissionMessage(error));
        }
        await requirePermission();
        if (currentTime() >= preview.expiresAt) reject("This history preview has expired. Preview your visits again; admitted videos can be retried without using another import.");
        const saved = (await api.storage.local.get(HISTORY_IMPORT_KEY))[HISTORY_IMPORT_KEY];
        const before = normalizeImportedHistory(saved, time2);
        const merged = new Map(before.visits.map((visit) => [visit.videoId, visit]));
        for (const visit of previewRows) {
          if (!selected.has(visit.videoId)) continue;
          const previous = merged.get(visit.videoId);
          if (!previous || visit.lastVisitTime > previous.lastVisitTime) merged.set(visit.videoId, { ...visit, importedAt: time2 });
        }
        const visits = [...merged.values()].sort((a, b) => b.lastVisitTime - a.lastVisitTime || a.videoId.localeCompare(b.videoId)).slice(0, MAX_IMPORTED_ROWS);
        await requirePermission();
        const changed = JSON.stringify(visits) !== JSON.stringify(before.visits) || JSON.stringify(saved) !== JSON.stringify({ schemaVersion: 1, visits: before.visits, updatedAt: before.updatedAt });
        const updatedAt = changed ? time2 : before.updatedAt;
        if (admission?.signal.aborted) reject("Import stopped. Your saved records are kept.");
        if (changed) await api.storage.local.set({ [HISTORY_IMPORT_KEY]: { schemaVersion: 1, visits, updatedAt } });
        return { ok: true, granted: true, visits, updatedAt };
      } catch (error) {
        if (error instanceof HistoryImportError) throw error;
        throw new HistoryImportError("Chrome history import could not be completed. Please try again; you can continue learning without importing.");
      } finally {
        admission = null;
      }
    });
  };
}
const LEARNING_STORE_PREFIX = "delta.learning.workspace.v1.";
const LEARNING_ROUTES = Object.freeze({ generate: "/api/learning/generate", validate: "/api/learning/validate", reteach: "/api/learning/reteach", pptx: "/api/learning/pptx" });
const MAX_STATE_BYTES = 25e4;
const boundedText = (value, max, label, empty2 = false) => {
  if (typeof value !== "string" || value.length > max || !empty2 && !value.trim()) throw Error(`Invalid ${label}.`);
  return value;
};
function normalizeLearningPayload(action, payload) {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw Error("Invalid learning request.");
  if (action === "generate") {
    const source2 = payload.source;
    const url = boundedText(source2?.videoUrl, 2048, "video URL");
    if (!isYouTubeUrl(url) || !validVideoId(youtubeVideoId(url))) throw Error("Enter a valid YouTube video URL.");
    const start = source2.start ?? 0, end = source2.end ?? start + 180;
    if (!Number.isFinite(start) || start < 0 || !Number.isFinite(end) || end <= start || end - start > 300 || end > 86400) throw Error("Choose a valid clip of up to five minutes.");
    const profile = payload.profile || {};
    if (!Array.isArray(profile.interests) || profile.interests.length > 5) throw Error("Choose up to five interests.");
    if (!["beginner", "some-experience"].includes(profile.level) || !["en", "zh-HK"].includes(profile.language)) throw Error("Invalid learning preferences.");
    return {
      source: { videoUrl: `https://www.youtube.com/watch?v=${youtubeVideoId(url)}`, title: boundedText(source2.title || "", 300, "video title", true), start, end },
      profile: { interests: profile.interests.map((value) => boundedText(value, 80, "interest")), level: profile.level, language: profile.language }
    };
  }
  if (!Object.hasOwn(LEARNING_ROUTES, action)) throw Error("Unsupported learning action.");
  const lessonToken = boundedText(payload.lessonToken, 1e5, "lesson token");
  if (action === "pptx") return { lessonToken };
  const formula = boundedText(payload.formula, 1e3, "formula", true);
  if (payload.taskId === void 0) return { lessonToken, formula };
  const taskId = boundedText(payload.taskId, 100, "practice task ID");
  if (/[\u0000-\u001f]/.test(taskId)) throw Error("Invalid practice task ID.");
  return { lessonToken, formula, taskId };
}
function interestSuggestions(data, importedVisits = [], accountEntries = []) {
  const watched = new Map(Object.entries(data?.videos || {}).filter(([, video]) => Array.isArray(video.ranges) && video.ranges.some(([a, b]) => b > a)));
  const imported = /* @__PURE__ */ new Map();
  for (const visit of (Array.isArray(importedVisits) ? importedVisits : []).slice(0, 1e3)) {
    if (!validVideoId(visit?.videoId) || typeof visit.title !== "string" || watched.has(visit.videoId) || imported.has(visit.videoId)) continue;
    imported.set(visit.videoId, { title: visit.title.slice(0, 300) });
  }
  const account2 = /* @__PURE__ */ new Map();
  for (const entry of Array.isArray(accountEntries) ? accountEntries : []) {
    if (!validVideoId(entry?.videoId) || typeof entry.title !== "string" || watched.has(entry.videoId) || imported.has(entry.videoId) || account2.has(entry.videoId)) continue;
    account2.set(entry.videoId, { title: entry.title.slice(0, 300) });
  }
  const videos = [...watched.values(), ...imported.values(), ...account2.values()];
  const source2 = account2.size ? "youtube-account-history-and-delta" : imported.size ? watched.size ? "delta-observed-and-imported" : "imported-visits" : "delta-observed";
  const message = account2.size ? "Local topic hints from imported YouTube watch history and other Delta records. History does not prove understanding or skills. Review suggestions before using them." : imported.size ? `Local topic hints from ${watched.size ? "observed playback and imported" : "imported"} YouTube page titles. Imported visits do not prove playback or skills. Review suggestions before using them.` : watched.size ? "Local suggestions from video titles with playback recorded by Delta on this Chrome browser. Review suggestions before using them." : "No local topic hints yet. Keep watching to discover suggestions. You can start learning without filling in interests.";
  const counts = /* @__PURE__ */ new Map();
  for (const video of videos) {
    const topic = topicForVideo({ title: video.title });
    if (topic.id.startsWith("other:")) continue;
    counts.set(topic.label, (counts.get(topic.label) || 0) + 1);
  }
  return { source: source2, suggestions: [...counts].map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count), message };
}
function learningMetadata(saved, endpoint) {
  return saved?.endpoint === endpoint ? {
    revision: Number.isSafeInteger(saved.revision) && saved.revision >= 0 ? saved.revision : 0,
    writerId: typeof saved.writerId === "string" ? saved.writerId.slice(0, 100) : ""
  } : { revision: 0, writerId: "" };
}
function skillsMetadata(saved) {
  return {
    skillsRevision: Number.isSafeInteger(saved?.revision) && saved.revision >= 0 ? saved.revision : 0,
    skillsWriterId: typeof saved?.writerId === "string" ? saved.writerId.slice(0, 100) : ""
  };
}
function createLearningHandler({ api, repository, readEndpoint, panelSender, contentSender: contentSender2, fetchImpl = globalThis.fetch }) {
  let stateWrites = Promise.resolve();
  const checkVideo = (videoId, sender) => {
    if (!validVideoId(videoId)) throw Error("Invalid video ID.");
    if (contentSender2(sender) && youtubeVideoId(sender.url) !== videoId) throw Error("Use learning content for the current video.");
  };
  return async function handleLearning(message, sender) {
    if (!panelSender(sender) && !contentSender2(sender)) throw Error("Unauthorized learning message source.");
    if (message.type === "LEARNING_INTERESTS") {
      const stored = (await api.storage.local.get(HISTORY_IMPORT_KEY))[HISTORY_IMPORT_KEY];
      const imported = normalizeImportedHistory(stored).visits;
      const history = normalizeAccountHistory((await api.storage.local.get(ACCOUNT_HISTORY_KEY))[ACCOUNT_HISTORY_KEY]);
      return { ok: true, result: interestSuggestions(await repository.read(), imported, history.accounts[history.activeAccountKey]?.entries || []) };
    }
    const skillsMessage = ["LEARNING_SKILLS_GET", "LEARNING_SKILLS_SET"].includes(message.type);
    if (!skillsMessage || contentSender2(sender)) checkVideo(message.videoId, sender);
    const endpoint = normalizeApiEndpoint(await readEndpoint());
    if (message.expectedEndpoint !== endpoint) throw Error("Learning service settings changed. Wait for the sidebar to update, then try again.");
    if (skillsMessage) {
      if (message.type === "LEARNING_SKILLS_GET") {
        const saved = (await api.storage.local.get(SKILLS_STORE_KEY))[SKILLS_STORE_KEY];
        const metadata2 = skillsMetadata(saved);
        return {
          ok: true,
          value: saved === void 0 ? null : normalizeSkills(saved?.value),
          endpoint,
          revision: metadata2.skillsRevision,
          writerId: metadata2.skillsWriterId
        };
      }
      if (!message.value || typeof message.value !== "object" || Array.isArray(message.value) || message.value.schemaVersion !== 1 || JSON.stringify(message.value).length > 5e4) throw Error("Invalid skill record format or size.");
      if (!Number.isSafeInteger(message.expectedRevision) || message.expectedRevision < 0) throw Error("Invalid skill revision.");
      const writerId = boundedText(message.writerId, 100, "window ID");
      const value = normalizeSkills(message.value), json = JSON.stringify(value);
      const save = async () => {
        if (normalizeApiEndpoint(await readEndpoint()) !== endpoint) throw Error("Learning service settings changed. Skill records were not overwritten.");
        const before = (await api.storage.local.get(SKILLS_STORE_KEY))[SKILLS_STORE_KEY];
        const metadata2 = skillsMetadata(before), revision = metadata2.skillsRevision;
        if (before && JSON.stringify(normalizeSkills(before.value)) === json) return { ok: true, endpoint, revision, writerId: metadata2.skillsWriterId };
        if (revision !== message.expectedRevision) return {
          ok: false,
          conflict: true,
          endpoint,
          revision,
          writerId: metadata2.skillsWriterId,
          error: "Another Delta view updated your skills. Load the latest records first."
        };
        await api.storage.local.set({ [SKILLS_STORE_KEY]: { revision: revision + 1, writerId, value } });
        return { ok: true, endpoint, revision: revision + 1, writerId };
      };
      const operation = stateWrites.then(save, save);
      stateWrites = operation.catch(() => {
      });
      return operation;
    }
    const key = `${LEARNING_STORE_PREFIX}${message.videoId}`;
    if (message.type === "LEARNING_STATE_GET") {
      const saved = (await api.storage.local.get(key))[key];
      return { ok: true, value: saved?.endpoint === endpoint ? saved.value : null, endpoint, ...learningMetadata(saved, endpoint) };
    }
    if (message.type === "LEARNING_STATE_SET") {
      const value = message.value;
      if (value !== null && (typeof value !== "object" || Array.isArray(value))) throw Error("Invalid saved lesson format.");
      if (value?.profile) {
        if (!Array.isArray(value.profile.interests) || value.profile.interests.length > 5) throw Error("Choose up to five interests.");
        value.profile.interests.forEach((item) => boundedText(item, 80, "interest"));
        if (value.profile.level != null && !["beginner", "some-experience"].includes(value.profile.level) || value.profile.language != null && !["en", "zh-HK"].includes(value.profile.language)) throw Error("Invalid learning preferences.");
      }
      if (value?.source) {
        const validatedSource = normalizeLearningPayload("generate", { source: { ...value.source, start: Number(value.source.start), end: Number(value.source.end) }, profile: { interests: [], level: "beginner", language: "en" } }).source;
        if (youtubeVideoId(validatedSource.videoUrl) !== message.videoId) throw Error("Source video does not match.");
      }
      if (value?.lessonToken) boundedText(value.lessonToken, 1e5, "lesson token");
      if (value?.formula != null) boundedText(value.formula, 1e3, "formula", true);
      const json = JSON.stringify(value);
      if (json.length > MAX_STATE_BYTES) throw Error("Saved lesson is too large.");
      if (!Number.isSafeInteger(message.expectedRevision) || message.expectedRevision < 0) throw Error("Invalid lesson revision.");
      const writerId = boundedText(message.writerId, 100, "window ID");
      const save = async () => {
        if (normalizeApiEndpoint(await readEndpoint()) !== endpoint) throw Error("Learning service settings changed. The previous lesson was not saved to the new service.");
        const before = (await api.storage.local.get(key))[key];
        const current = learningMetadata(before, endpoint);
        if (before?.endpoint === endpoint && JSON.stringify(before.value) === json) return { ok: true, endpoint, ...current };
        if (current.revision !== message.expectedRevision) return {
          ok: false,
          conflict: true,
          endpoint,
          ...current,
          error: "Another Delta view updated this lesson. Reloading the latest progress."
        };
        const revision = current.revision + 1;
        await api.storage.local.set({ [key]: { endpoint, revision, writerId, value: JSON.parse(json) } });
        return { ok: true, endpoint, revision, writerId };
      };
      const operation = stateWrites.then(save, save);
      stateWrites = operation.catch(() => {
      });
      return operation;
    }
    if (message.type !== "LEARNING_REQUEST" || !Object.hasOwn(LEARNING_ROUTES, message.action)) throw Error("Unsupported learning action.");
    const payload = normalizeLearningPayload(message.action, message.payload);
    if (message.action === "generate" && youtubeVideoId(payload.source.videoUrl) !== message.videoId) throw Error("Source video does not match.");
    if (!await api.permissions.contains({ origins: [endpointPermission(endpoint)] })) throw Error("Click “Create lesson” in the Delta native sidebar to allow the learning service, then return here.");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 95e3);
    try {
      const response = await fetchImpl(`${endpoint}${LEARNING_ROUTES[message.action]}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal,
        redirect: "error",
        credentials: "omit",
        cache: "no-store"
      });
      if (!response.ok) {
        let detail = "";
        try {
          const body = await response.json();
          const message2 = typeof body.error === "string" ? body.error : body.error?.message || body.message;
          detail = typeof message2 === "string" ? message2.slice(0, 300) : "";
        } catch {
        }
        throw Error(detail || `The learning service could not complete the request (HTTP ${response.status}).`);
      }
      if (message.action === "pptx") {
        const bytes = new Uint8Array(await response.arrayBuffer());
        if (bytes.length > 8e6) throw Error("The slide file is too large.");
        let binary = "";
        for (let index = 0; index < bytes.length; index += 32768) binary += String.fromCharCode(...bytes.subarray(index, index + 32768));
        if (normalizeApiEndpoint(await readEndpoint()) !== endpoint) throw Error("Learning service settings changed. The previous service file was not downloaded.");
        return { ok: true, result: { base64: btoa(binary), mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation" } };
      }
      const resultText = await response.text();
      if (resultText.length > 25e4) throw Error("The lesson response is too large.");
      if (normalizeApiEndpoint(await readEndpoint()) !== endpoint) throw Error("Learning service settings changed. The previous service result was not applied.");
      return { ok: true, result: JSON.parse(resultText) };
    } catch (error) {
      if (error.name === "AbortError") throw Error("Lesson creation timed out. Your watch history is saved. Try again.");
      throw error;
    } finally {
      clearTimeout(timer);
    }
  };
}
export {
  watchedSeconds as $,
  ANALYSIS_SETTINGS_KEY as A,
  createPracticeEvidence as B,
  addPracticeEvidence as C,
  DEFAULT_API_ENDPOINT as D,
  normalizeMapClassifications as E,
  mapPathId as F,
  buildPersonalMap as G,
  createMapAnalysisClient as H,
  MapAnalysisError as I,
  usesHostedMap as J,
  metadataForMap as K,
  LIVE_PREFIX as L,
  MAP_HOSTED_BATCH_SIZE as M,
  markMapReviewed as N,
  MAP_CLASSIFICATION_KEY as O,
  PANEL_INTENT_KEY as P,
  mapAssignmentMatches as Q,
  normalizeMapEndpoint as R,
  SKILLS_STORE_KEY as S,
  mapReviewMatches as T,
  videoValue as U,
  setFamiliarity as V,
  markStarted as W,
  DEFAULT_ACCOUNT_HISTORY_RANGE as X,
  ACCOUNT_HISTORY_IMPORT_SCOPES as Y,
  openHostedAction as Z,
  formatTime as _,
  createHostedActionBroker as a,
  LEARNING_PILOT as a0,
  learningSourceVideo as a1,
  emptyData as a2,
  STORE_KEY as a3,
  LEARNING_LIBRARY_KEY as a4,
  HISTORY_IMPORT_KEY as a5,
  ACCOUNT_HISTORY_KEY as a6,
  fetchAnalysis as a7,
  createImportAdmission as b,
  createRepository as c,
  createHistoryImportHandler as d,
  episodes as e,
  createAccountHistoryHandler as f,
  getLearningRouteProgress as g,
  createLearningLibrary as h,
  createLearningHandler as i,
  applyRecording as j,
  normalizeApiEndpoint as k,
  endpointPermission as l,
  mergeIntervals as m,
  normalizeData as n,
  analysisPayload as o,
  validateAnalysisResponse as p,
  ANALYSIS_RESULT_KEY as q,
  isYouTubeUrl as r,
  savedAnalysisView as s,
  LEARNING_STORE_PREFIX as t,
  learningMetadata as u,
  validVideoId as v,
  learningEntryState as w,
  skillsMetadata as x,
  emptySkills as y,
  normalizeSkills as z
};
